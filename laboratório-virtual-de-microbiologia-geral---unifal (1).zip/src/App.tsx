/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Beaker, 
  BookOpen, 
  Award, 
  HelpCircle, 
  ChevronRight, 
  CheckCircle2, 
  Sparkles, 
  Activity, 
  X, 
  GraduationCap, 
  Users,
  Microscope,
  Info
} from 'lucide-react';
import Header from './components/Header';
import Footer from './components/Footer';
import ExpBreadMold from './components/ExpBreadMold';
import ExpYeastFermentation from './components/ExpYeastFermentation';
import ExpMicroscopy from './components/ExpMicroscopy';
import LabReport from './components/LabReport';
import { ExperimentId, Experiment } from './types';

export default function App() {
  const [activeTab, setActiveTab] = useState<ExperimentId | 'report'>('bread-mold');
  const [completedExperiments, setCompletedExperiments] = useState<ExperimentId[]>([]);
  const [showIntroModal, setShowIntroModal] = useState(true);

  const experiments: Experiment[] = [
    {
      id: 'bread-mold',
      title: '1. Crescimento do Bolor de Pão',
      subtitle: 'Rhizopus stolonifer',
      description: 'Investigue o efeito da humidade, temperatura e luz no crescimento vegetativo e esporulação de fungos filamentosos (Zygomycota).',
      difficulty: 'Fácil',
      duration: '7 dias (simulado)',
      topic: 'Fungos Filamentosos'
    },
    {
      id: 'yeast',
      title: '2. Fermentação por Leveduras',
      subtitle: 'Saccharomyces cerevisiae',
      description: 'Observe a produção anaeróbica de CO₂ testando açúcares simples, amidos complexos e adoçantes artificiais sob diferentes temperaturas térmicas.',
      difficulty: 'Médio',
      duration: '30 minutos (simulado)',
      topic: 'Metabolismo Bioquímico'
    },
    {
      id: 'microscopy',
      title: '3. Microscopia Citológica',
      subtitle: 'Citologia e Esporos',
      description: 'Domine os botões de foco e intensidade luminosa para identificar hifas, esporângios, conídios e brotamentos de leveduras preparadas.',
      difficulty: 'Difícil',
      duration: 'Ajuste Dinâmico',
      topic: 'Citologia Fúngica'
    }
  ];

  const handleMarkAsCompleted = (id: ExperimentId) => {
    if (!completedExperiments.includes(id)) {
      setCompletedExperiments(prev => [...prev, id]);
    }
  };

  const handleResetProgress = () => {
    setCompletedExperiments([]);
    setActiveTab('bread-mold');
  };

  return (
    <div className="min-h-screen bg-[#FAF7F2] text-stone-800 flex flex-col font-sans selection:bg-emerald-800 selection:text-white">
      
      {/* HEADER */}
      <Header onOpenIntro={() => setShowIntroModal(true)} />

      {/* CORE LAB STATS / HERO BAR */}
      <div className="bg-[#F4ECE1] border-b border-stone-200 py-4 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-start md:items-center gap-4 text-xs">
          
          {/* Welcome and objective banner */}
          <div className="flex items-center space-x-2.5">
            <span className="h-2.5 w-2.5 rounded-full bg-emerald-600 animate-ping shrink-0" />
            <span className="text-stone-600">
              <strong className="text-stone-800">Sessão Ativa de Prática:</strong> Ensino interativo de Microbiologia e Biologia Celular para ciências biológicas e saúde.
            </span>
          </div>

          {/* Quick Stats overview */}
          <div className="flex items-center space-x-6">
            <div className="flex items-center space-x-2">
              <span className="text-stone-500">Módulos Feitos:</span>
              <span className="font-bold font-mono text-emerald-800 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded">
                {completedExperiments.length} / 3
              </span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="text-stone-500">Aproveitamento:</span>
              <span className="font-bold font-mono text-amber-800 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded">
                {Math.round((completedExperiments.length / 3) * 100)}%
              </span>
            </div>
          </div>

        </div>
      </div>

      {/* MAIN CONTAINER CONTENT */}
      <main className="flex-grow max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 w-full">
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-8 items-start">
          
          {/* Left Navigation Rails - List of all 3 experiments and Lab Report */}
          <div className="xl:col-span-3 flex flex-col space-y-3">
            <div className="bg-white border border-stone-200 p-4 rounded-2xl shadow-sm">
              <div className="text-stone-500 text-[10px] uppercase font-extrabold tracking-widest mb-3 flex items-center">
                <BookOpen className="h-4 w-4 mr-1.5 text-emerald-700" />
                Menu de Atividades
              </div>
              
              <div className="space-y-2">
                {experiments.map((exp) => {
                  const isSelected = activeTab === exp.id;
                  const isDone = completedExperiments.includes(exp.id);
                  return (
                    <button
                      key={exp.id}
                      onClick={() => {
                        setActiveTab(exp.id);
                        handleMarkAsCompleted(exp.id);
                      }}
                      className={`w-full p-3.5 rounded-xl text-left border transition-all flex flex-col relative overflow-hidden group ${
                        isSelected 
                          ? 'bg-emerald-50/70 border-emerald-600 text-emerald-950 shadow-sm' 
                          : 'bg-stone-50/50 border-stone-200 text-stone-700 hover:border-emerald-600/50 hover:bg-emerald-50/20'
                      }`}
                      id={`tab-btn-${exp.id}`}
                    >
                      <div className="flex justify-between items-start w-full">
                        <span className="font-bold text-xs text-stone-800 group-hover:text-emerald-900 transition-colors">
                          {exp.title}
                        </span>
                        {isDone && (
                          <span className="bg-emerald-100 border border-emerald-200 text-emerald-800 font-bold text-[9px] px-1.5 py-0.5 rounded">
                            ✓ Feito
                          </span>
                        )}
                      </div>
                      
                      <span className="text-[10px] text-emerald-800 font-medium italic mt-1 font-mono">
                        {exp.subtitle}
                      </span>
                      
                      <span className="text-[10px] text-stone-500 mt-2 line-clamp-2 leading-relaxed">
                        {exp.description}
                      </span>

                      {/* Level Indicator Footer */}
                      <div className="flex justify-between items-center text-[9px] mt-3 pt-2.5 border-t border-stone-200 font-semibold uppercase tracking-wider text-stone-500">
                        <span>{exp.topic}</span>
                        <span className={exp.difficulty === 'Fácil' ? 'text-emerald-700' : exp.difficulty === 'Médio' ? 'text-amber-700' : 'text-rose-700'}>
                          {exp.difficulty}
                        </span>
                      </div>
                    </button>
                  );
                })}

                {/* Lab report tab button */}
                <button
                  onClick={() => setActiveTab('report')}
                  className={`w-full p-4 rounded-xl text-left border transition-all flex items-center justify-between group mt-4 ${
                    activeTab === 'report'
                      ? 'bg-emerald-50 border-emerald-600 text-emerald-900 shadow-sm'
                      : 'bg-stone-50/80 border-stone-200 text-stone-700 hover:border-emerald-600/50 hover:bg-emerald-50/20'
                  }`}
                  id="tab-btn-report"
                >
                  <div className="flex items-center space-x-2.5">
                    <div className="bg-white p-1.5 rounded-lg border border-stone-200">
                      <Award className="h-4.5 w-4.5 text-emerald-700" />
                    </div>
                    <div>
                      <div className="font-bold text-xs text-stone-800 group-hover:text-emerald-900">Laudo Acadêmico</div>
                      <div className="text-[9.5px] text-stone-500 font-medium font-sans">Emitir Notas e Certificado</div>
                    </div>
                  </div>
                  <ChevronRight className="h-4.5 w-4.5 text-stone-400 group-hover:text-emerald-700 transition-colors shrink-0" />
                </button>
              </div>
            </div>

            {/* Quick guide of contributors on sidebar too */}
            <div className="bg-white border border-stone-200 p-4 rounded-2xl text-xs text-stone-500 space-y-1.5">
              <span className="font-bold text-[10px] text-stone-600 uppercase tracking-widest block">Créditos Científicos</span>
              <p>Membros criadores originais do laboratório:</p>
              <div className="text-stone-700 font-bold flex flex-wrap gap-1.5 mt-1 font-mono text-[11px]">
                <span className="bg-stone-100 px-1.5 py-0.5 rounded border border-stone-200">Evânia</span>
                <span className="bg-stone-100 px-1.5 py-0.5 rounded border border-stone-200">Helder</span>
                <span className="bg-stone-100 px-1.5 py-0.5 rounded border border-stone-200">Raphael</span>
                <span className="bg-stone-100 px-1.5 py-0.5 rounded border border-stone-200">Zilar</span>
              </div>
            </div>
          </div>

          {/* Right Active Lab Workspace */}
          <div className="xl:col-span-9">
            
            {/* EXP 1: BREAD MOLD */}
            {activeTab === 'bread-mold' && <ExpBreadMold />}

            {/* EXP 2: YEAST FERMENTATION */}
            {activeTab === 'yeast' && <ExpYeastFermentation />}

            {/* EXP 3: MICROSCOPY */}
            {activeTab === 'microscopy' && <ExpMicroscopy />}

            {/* LAB REPORT & CERTIFICATE */}
            {activeTab === 'report' && (
              <LabReport 
                completedExperiments={completedExperiments} 
                onResetProgress={handleResetProgress}
              />
            )}

            {/* Auto trigger completions */}
            {activeTab !== 'report' && !completedExperiments.includes(activeTab) && (
              <div className="mt-4 bg-white border border-stone-200 p-4 rounded-xl flex justify-between items-center gap-4 shadow-sm">
                <div className="flex items-center space-x-2.5 text-xs text-stone-500">
                  <span className="h-2.5 w-2.5 rounded-full bg-emerald-600" />
                  <span>Ao concluir ou interagir com esta prática, você acumula progresso para seu Laudo.</span>
                </div>
                <button
                  onClick={() => handleMarkAsCompleted(activeTab)}
                  className="py-1.5 px-3 rounded-lg bg-emerald-800 hover:bg-emerald-700 text-white font-bold text-xs border border-emerald-900 transition-all flex items-center space-x-1 shrink-0"
                  id={`btn-manual-completar-${activeTab}`}
                >
                  <CheckCircle2 className="h-3.5 w-3.5" />
                  <span>Registrar Prática como Feita</span>
                </button>
              </div>
            )}

          </div>

        </div>
      </main>

      {/* FOOTER */}
      <Footer />

      {/* INTRODUCTION MODAL (Shows automatically on first load to contextualize UNIFAL and the student credits) */}
      {showIntroModal && (
        <div className="fixed inset-0 bg-stone-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white border border-stone-200 max-w-2xl w-full rounded-2xl shadow-xl p-6 sm:p-8 relative overflow-hidden flex flex-col max-h-[90vh]">
            
            {/* Close button */}
            <button
              onClick={() => setShowIntroModal(false)}
              className="absolute top-4 right-4 text-stone-400 hover:text-stone-600 hover:bg-stone-100 p-1.5 rounded-lg transition-all"
              id="btn-fechar-intro"
            >
              <X className="h-5 w-5" />
            </button>

            {/* Brand Logo & Banner */}
            <div className="flex items-center space-x-4 border-b border-stone-200 pb-5 mb-5">
              <div className="bg-emerald-50 border border-emerald-200 p-3 rounded-xl text-emerald-800">
                <Microscope className="h-8 w-8" />
              </div>
              <div>
                <span className="text-[10px] font-extrabold tracking-widest text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 uppercase">
                  UNIFAL-MG
                </span>
                <h2 className="text-xl sm:text-2xl font-bold text-stone-900 mt-1">
                  Laboratório Virtual de Microbiologia Geral
                </h2>
                <span className="text-xs text-stone-500 font-medium">Instituto de Ciências da Natureza • Ciências Biológicas</span>
              </div>
            </div>

            {/* Welcome and Context */}
            <div className="flex-grow overflow-y-auto space-y-4 text-xs sm:text-sm text-stone-600 leading-relaxed pr-2 custom-scrollbar">
              <p>
                Seja muito bem-vindo ao <strong>Laboratório Virtual de Microbiologia Geral da Universidade Federal de Alfenas (UNIFAL-MG)</strong>. Este ambiente foi projetado para simular rotinas laboratoriais de microbiologia, proporcionando aprendizado interativo sobre a estrutura, bioquímica, reprodução e taxonomia dos fungos e microrganismos.
              </p>
              
              <p>
                Os fungos constituem o Reino Fungi, organismos eucarióticos heterotróficos essenciais para a reciclagem de matéria orgânica no planeta, além de vasta importância industrial, alimentícia, médica e farmacológica.
              </p>

              {/* Grid listing the 3 experiments */}
              <div className="bg-[#FAF7F2] p-4 rounded-xl border border-stone-200 space-y-2.5">
                <span className="text-[10px] font-bold text-stone-500 uppercase tracking-widest block">3 Experimentos Práticos Disponíveis:</span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div className="flex items-start space-x-2">
                    <span className="text-emerald-700 shrink-0 mt-0.5">✔</span>
                    <div>
                      <strong className="text-stone-800 block">1. Bolor de Pão</strong>
                      <span className="text-stone-500 text-[11px]">Ecologia e fatores ambientais em Rhizopus.</span>
                    </div>
                  </div>
                  <div className="flex items-start space-x-2">
                    <span className="text-emerald-700 shrink-0 mt-0.5">✔</span>
                    <div>
                      <strong className="text-stone-800 block">2. Fermentação</strong>
                      <span className="text-stone-500 text-[11px]">Metabolismo anaeróbico de Saccharomyces.</span>
                    </div>
                  </div>
                  <div className="flex items-start space-x-2">
                    <span className="text-emerald-700 shrink-0 mt-0.5">✔</span>
                    <div>
                      <strong className="text-stone-800 block">3. Microscopia Virtual</strong>
                      <span className="text-stone-500 text-[11px]">Ajustes de foco em lâminas histológicas.</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Creators Team Mention */}
              <div className="bg-emerald-50/50 border border-emerald-200 p-4 rounded-xl">
                <div className="flex items-center space-x-1.5 text-xs font-bold text-emerald-800 uppercase tracking-wider mb-1.5">
                  <Users className="h-4 w-4" />
                  <span>Projeto de Desenvolvimento Acadêmico</span>
                </div>
                <p className="text-xs text-stone-600 leading-relaxed">
                  Este laboratório virtual interativo foi concebido e realizado como projeto didático pelos membros acadêmicos da UNIFAL-MG:
                </p>
                <div className="flex flex-wrap gap-1.5 font-bold text-stone-700 text-xs mt-2 bg-white px-3 py-1.5 rounded-lg border border-stone-200">
                  <span className="bg-stone-50 px-2 py-0.5 rounded">Evânia</span>
                  <span className="bg-stone-50 px-2 py-0.5 rounded">Helder</span>
                  <span className="bg-stone-50 px-2 py-0.5 rounded">Raphael</span>
                  <span className="bg-stone-50 px-2 py-0.5 rounded">Zilar</span>
                </div>
              </div>
            </div>

            {/* Confirm / Continue Button */}
            <div className="border-t border-stone-200 pt-4 mt-5 flex justify-end">
              <button
                onClick={() => setShowIntroModal(false)}
                className="py-2.5 px-6 bg-emerald-800 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow transition-all flex items-center space-x-1.5"
                id="btn-entrar-lab"
              >
                <span>Acessar Laboratório Virtual</span>
                <ChevronRight className="h-4 w-4" />
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
