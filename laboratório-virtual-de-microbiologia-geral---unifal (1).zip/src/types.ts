export type ExperimentId = 'bread-mold' | 'yeast' | 'microscopy';

export interface Experiment {
  id: ExperimentId;
  title: string;
  subtitle: string;
  description: string;
  difficulty: 'Fácil' | 'Médio' | 'Difícil';
  duration: string; // e.g. "7 dias (simulado)", "30 minutos"
  topic: string; // e.g. "Zigomicetos", "Ascomicetos"
}

export interface BreadMoldConditions {
  humidity: 'umido' | 'seco';
  temperature: 'quente' | 'frio';
  light: 'escuro' | 'claro';
}

export interface YeastConditions {
  substrate: 'acucar' | 'adocante' | 'amido' | 'controle';
  temperature: 'quente' | 'frio' | 'ambiente';
}

export interface MicroscopeState {
  slideId: 'aspergillus' | 'penicillium' | 'yeast' | 'rhizopus';
  zoom: 4 | 10 | 40 | 100;
  focus: number; // 0 to 100, where 50 is perfect focus
  lightIntensity: number; // 0 to 100
}

