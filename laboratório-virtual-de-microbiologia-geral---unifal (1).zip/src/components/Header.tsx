import React from 'react';
import { Beaker, GraduationCap, Microscope, Info } from 'lucide-react';

interface HeaderProps {
  onOpenIntro: () => void;
}

export default function Header({ onOpenIntro }: HeaderProps) {
  return (
    <header className="bg-[#1C3A27] border-b border-[#142A1C] text-white shadow sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <div className="flex items-center space-x-4">
            <div className="bg-[#2D5A3F] p-2.5 rounded-xl shadow border border-emerald-500/20 flex items-center justify-center">
              <Microscope className="h-7 w-7 text-emerald-100" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-xs font-semibold uppercase tracking-widest text-[#D4EADE] bg-[#112418] px-2 py-0.5 rounded border border-[#2D5A3F]">
                  UNIFAL-MG
                </span>
                <span className="text-xs text-emerald-200/85 hidden sm:inline-block">
                  Instituto de Ciências da Natureza
                </span>
              </div>
              <h1 className="text-lg sm:text-xl md:text-2xl font-bold tracking-tight text-white mt-0.5">
                Laboratório Virtual de Microbiologia Geral
              </h1>
            </div>
          </div>
          
          <div className="flex items-center space-x-3">
            <button
              onClick={onOpenIntro}
              className="flex items-center space-x-2 px-3.5 py-2 rounded-lg bg-[#2D5A3F] hover:bg-[#38704F] text-[#D4EADE] hover:text-white transition-all text-sm border border-[#38704F]/60 shadow-sm"
              title="Sobre o Laboratório"
              id="btn-sobre-lab"
            >
              <Info className="h-4 w-4" />
              <span className="hidden md:inline font-medium">Sobre o Lab</span>
            </button>
            <div className="flex items-center space-x-2 bg-[#112418]/60 border border-[#2D5A3F]/50 px-3 py-1.5 rounded-lg text-[#D4EADE] text-xs font-medium">
              <GraduationCap className="h-4 w-4 text-[#A7D7C1]" />
              <span className="hidden lg:inline">Graduação em Ciências Biológicas</span>
              <span className="lg:hidden">Biológicas</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
