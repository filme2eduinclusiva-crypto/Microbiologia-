import React, { useState } from 'react';
import { Award, CheckCircle, FileText, Printer, ShieldCheck, HelpCircle, AlertCircle, RefreshCw } from 'lucide-react';
import { ExperimentId } from '../types';

interface LabReportProps {
  completedExperiments: ExperimentId[];
  onResetProgress: () => void;
}

interface QuizQuestion {
  id: number;
  question: string;
  options: string[];
  correctIdx: number;
  explanation: string;
}

export default function LabReport({ completedExperiments, onResetProgress }: LabReportProps) {
  const [studentName, setStudentName] = useState('');
  const [selectedAnswers, setSelectedAnswers] = useState<Record<number, number>>({});
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const [quizScore, setQuizScore] = useState(0);

  const quizQuestions: QuizQuestion[] = [
    {
      id: 1,
      question: "Por que as leveduras (Saccharomyces cerevisiae) fermentam vigorosamente a glicose/sacarose, mas não o adoçante sucralose?",
      options: [
        "Porque o adoçante mata as leveduras devido à toxicidade do cloro contido na sucralose.",
        "Porque os fungos necessitam de luz para metabolizar a sucralose artificial.",
        "Porque as leveduras carecem de vias metabólicas e enzimas específicas (como as hexocinases) que reconheçam e clivem a molécula sintética de sucralose.",
        "Porque a sucralose evapora do banho-maria morno de imediato."
      ],
      correctIdx: 2,
      explanation: "Os fungos expressam transportadores de membrana e enzimas reguladas para carboidratos biológicos (glicose, frutose, sacarose). Moléculas sintéticas não têm encaixe estereoquímico correspondente em suas vias enzimáticas anaeróbicas."
    },
    {
      id: 2,
      question: "Qual característica citológica visualizada no microscópio ótico diferencia os fungos filamentosos (morfologia assexual do Rhizopus ou Aspergillus) das leveduras?",
      options: [
        "A presença de vacúolos de clorofila ativa nos fungos filamentosos.",
        "O corpo constituído por hifas multicelulares (micélio) nos filamentosos, versus células isoladas ovóides em brotamento (leveduras).",
        "A locomoção activa por flagelos proteicos das leveduras.",
        "O tamanho, sendo as leveduras 1000 vezes maiores que as hifas filamentosas."
      ],
      correctIdx: 1,
      explanation: "Os fungos filamentosos crescem de forma multicelular apical em hifas, formando micélios que sustentam estruturas de conídios. Leveduras são fungos unicelulares esféricos que proliferam por brotamento celular assexual."
    },
    {
      id: 3,
      question: "No experimento do bolor de pão, por que a refrigeração (4°C) impede que o pão seja colonizado em 7 dias?",
      options: [
        "Porque o frio congelante destrói fisicamente e dissolve a quitina das paredes celulares dos esporos de Rhizopus.",
        "Porque o frio bloqueia a entrada de oxigênio gasoso na estufa de incubação.",
        "Porque as baixas temperaturas inibem drasticamente as reações enzimáticas e o transporte através da membrana celular, suspendendo a germinação e o crescimento celular vegetativo do fungo.",
        "Porque a luz da geladeira desativa o fototropismo positivo do bolor de pão."
      ],
      correctIdx: 2,
      explanation: "A baixa temperatura reduz a energia cinética das enzimas digestivas do Rhizopus. Elas perdem a capacidade de quebrar o amido do pão de forma acelerada, congelando o crescimento sem necessariamente matar o esporo imediatamente."
    }
  ];

  const handleSelectOption = (qId: number, oIdx: number) => {
    if (quizSubmitted) return;
    setSelectedAnswers(prev => ({ ...prev, [qId]: oIdx }));
  };

  const handleSubmitQuiz = (e: React.FormEvent) => {
    e.preventDefault();
    if (!studentName.trim()) return;

    let score = 0;
    quizQuestions.forEach((q) => {
      if (selectedAnswers[q.id] === q.correctIdx) {
        score += 10 / quizQuestions.length;
      }
    });

    setQuizScore(score);
    setQuizSubmitted(true);
  };

  const handlePrint = () => {
    window.print();
  };

  const resetQuiz = () => {
    setSelectedAnswers({});
    setQuizSubmitted(false);
    setQuizScore(0);
  };

  return (
    <div className="bg-white border border-stone-200 rounded-2xl p-6 shadow-sm" id="lab-report">
      <div className="border-b border-stone-200 pb-4 mb-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <span className="text-xs font-semibold px-2.5 py-1 rounded bg-emerald-50 text-emerald-800 border border-emerald-200/60">
            Relatório de Aproveitamento
          </span>
          <h2 className="text-2xl font-bold text-stone-900 mt-2">
            Laudo Acadêmico & Caderno de Exercícios
          </h2>
          <p className="text-sm text-stone-600 mt-1">
            Certifique sua participação, responda as questões teóricas e emita o certificado oficial do laboratório virtual de UNIFAL-MG.
          </p>
        </div>
        
        {quizSubmitted && (
          <button
            onClick={handlePrint}
            className="py-2.5 px-4 rounded-xl bg-white hover:bg-stone-50 text-stone-700 hover:text-stone-900 border border-stone-200 font-bold text-xs transition-all flex items-center space-x-2 shadow-xs"
            id="btn-imprimir-laudo"
          >
            <Printer className="h-4 w-4" />
            <span>Imprimir Laudo</span>
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Progress status & Student registration */}
        <div className="lg:col-span-4 flex flex-col space-y-6">
          
          {/* Progress Status Card */}
          <div className="bg-[#FAF7F2] border border-stone-200 p-5 rounded-xl space-y-4">
            <h3 className="text-xs font-bold text-stone-500 uppercase tracking-wider">Status das Atividades Práticas</h3>
            
            <div className="space-y-3">
              {[
                { id: 'bread-mold', title: 'Exp 1: Bolor de Pão' },
                { id: 'yeast', title: 'Exp 2: Fermentação' },
                { id: 'microscopy', title: 'Exp 3: Microscopia' },
              ].map((exp) => {
                const completed = completedExperiments.includes(exp.id as ExperimentId);
                return (
                  <div key={exp.id} className="flex items-center justify-between text-xs p-2.5 rounded bg-white border border-stone-200/80">
                    <span className="text-stone-700 font-medium">{exp.title}</span>
                    <span className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                      completed 
                        ? 'bg-emerald-50 text-emerald-800 border border-emerald-200/60' 
                        : 'bg-stone-50 text-stone-400 border border-stone-200/40'
                    }`}>
                      {completed ? '✓ Concluído' : 'Pendente'}
                    </span>
                  </div>
                );
              })}
            </div>

            <div className="pt-4 border-t border-stone-200 flex justify-between text-xs font-semibold text-stone-500">
              <span>Experimentos Feitos:</span>
              <span className="text-emerald-700 font-mono font-bold">{completedExperiments.length} / 3</span>
            </div>

            <div className="w-full bg-stone-200 rounded-full h-2 overflow-hidden">
              <div 
                className="bg-emerald-800 h-full transition-all duration-500"
                style={{ width: `${(completedExperiments.length / 3) * 100}%` }}
              />
            </div>
          </div>

          {/* Student Info Registration Form */}
          {!quizSubmitted ? (
            <div className="bg-[#FAF7F2] border border-stone-200 p-5 rounded-xl space-y-3">
              <h3 className="text-xs font-bold text-stone-500 uppercase tracking-wider">Identificação do Aluno</h3>
              <p className="text-[11px] text-stone-500 leading-relaxed">Insira seu nome completo para que possamos emitir a nota e o certificado do laudo acadêmico de microbiologia geral.</p>
              
              <div>
                <input
                  type="text"
                  placeholder="Seu nome completo..."
                  value={studentName}
                  onChange={(e) => setStudentName(e.target.value)}
                  className="w-full py-2.5 px-3 bg-white border border-stone-200 rounded-lg text-stone-800 text-xs focus:outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 transition-colors"
                  id="student-name-input"
                />
              </div>
            </div>
          ) : (
            <div className="bg-emerald-50/30 border border-emerald-200/60 p-5 rounded-xl text-center space-y-3 animate-fade-in">
              <Award className="h-12 w-12 text-emerald-800 mx-auto animate-bounce animate-duration-1000" />
              <div>
                <div className="text-xs text-emerald-800 font-bold uppercase tracking-widest">Laudo Validado</div>
                <h4 className="text-base font-extrabold text-stone-900 mt-1">{studentName}</h4>
                <div className="text-[11px] text-stone-500 mt-1">UNIFAL-MG • Instituto de Ciências da Natureza</div>
              </div>
              
              <div className="bg-[#FAF7F2] p-3 rounded-lg border border-stone-200">
                <span className="text-[10px] uppercase font-bold text-stone-500 block">Média Final</span>
                <span className={`text-2xl font-black font-mono ${quizScore >= 7.0 ? 'text-emerald-800' : 'text-amber-800'}`}>
                  {quizScore.toFixed(1)} / 10.0
                </span>
                <span className="text-[10px] text-stone-500 block mt-1">
                  {quizScore >= 7.0 ? 'Aprovado por Aproveitamento!' : 'Estude os logs e tente novamente!'}
                </span>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={resetQuiz}
                  className="flex-1 py-2 rounded-lg bg-white hover:bg-stone-50 text-stone-600 border border-stone-200 text-xs font-semibold transition-all flex items-center justify-center space-x-1 shadow-xs"
                  id="btn-refazer-quiz"
                >
                  <RefreshCw className="h-3.5 w-3.5" />
                  <span>Refazer Prova</span>
                </button>
              </div>
            </div>
          )}

          {/* Reset all laboratory progress button */}
          <button
            onClick={onResetProgress}
            className="py-2.5 px-4 rounded-xl text-stone-500 hover:text-stone-700 hover:bg-stone-50/50 text-xs font-semibold transition-all flex items-center justify-center space-x-2"
            id="btn-reset-laboratorio"
          >
            <span>Reiniciar Todo o Laboratório</span>
          </button>
        </div>

        {/* Right Column: Quiz questions / Printable Laudo Paper */}
        <div className="lg:col-span-8">
          
          {!quizSubmitted ? (
            <form onSubmit={handleSubmitQuiz} className="space-y-6">
              <div className="bg-[#FAF7F2] border border-stone-200 p-5 rounded-xl">
                <div className="flex items-center space-x-2 text-emerald-800 font-bold text-sm border-b border-stone-200 pb-3 mb-4">
                  <HelpCircle className="h-4.5 w-4.5" />
                  <span>Avaliação de Compreensão Fúngica</span>
                </div>

                <div className="space-y-6">
                  {quizQuestions.map((q, qIdx) => (
                    <div key={q.id} className="space-y-3 border-b border-stone-200 pb-5 last:border-0 last:pb-0">
                      <div className="flex items-start space-x-2.5">
                        <span className="text-xs bg-stone-200 text-stone-600 px-2 py-0.5 rounded font-mono shrink-0">Q{qIdx + 1}</span>
                        <h4 className="text-xs font-bold text-stone-800 leading-relaxed">{q.question}</h4>
                      </div>

                      <div className="grid grid-cols-1 gap-2 pl-8">
                        {q.options.map((opt, oIdx) => {
                          const isSelected = selectedAnswers[q.id] === oIdx;
                          return (
                            <button
                              key={oIdx}
                              type="button"
                              onClick={() => handleSelectOption(q.id, oIdx)}
                              className={`text-left p-2.5 rounded-lg text-[11px] font-medium border transition-all leading-relaxed ${
                                isSelected
                                  ? 'bg-emerald-50 border-emerald-600 text-emerald-900 font-semibold'
                                  : 'bg-white border-stone-200 text-stone-600 hover:border-stone-300 hover:bg-stone-50'
                              }`}
                              id={`q-${q.id}-opt-${oIdx}`}
                            >
                              <div className="flex items-start space-x-2">
                                <span className={`w-4 h-4 rounded-full border shrink-0 mt-0.5 flex items-center justify-center text-[9px] font-bold ${
                                  isSelected ? 'border-emerald-600 bg-emerald-800 text-white' : 'border-stone-300 bg-stone-50 text-stone-600'
                                }`}>
                                  {String.fromCharCode(65 + oIdx)}
                                </span>
                                <span>{opt}</span>
                              </div>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex justify-end">
                <button
                  type="submit"
                  disabled={!studentName.trim() || Object.keys(selectedAnswers).length < quizQuestions.length}
                  className="py-3 px-6 bg-emerald-800 hover:bg-emerald-700 disabled:bg-stone-100 disabled:text-stone-400 text-white rounded-xl text-xs font-bold shadow-sm transition-all flex items-center space-x-2"
                  id="btn-submeter-quiz"
                >
                  <ShieldCheck className="h-4 w-4" />
                  <span>Submeter Laudo Acadêmico</span>
                </button>
              </div>
            </form>
          ) : (
            
            /* PRINTABLE ACADEMIC PAPER LAUDO SHEET */
            <div className="bg-white text-stone-900 rounded-xl p-8 border-4 border-double border-stone-300 shadow-lg space-y-6 animate-fade-in font-serif" id="laudo-papel-impressao">
              
              {/* UNIFAL Letterhead Header */}
              <div className="text-center border-b-2 border-stone-900 pb-4 space-y-1">
                <div className="text-xs tracking-widest font-sans font-bold uppercase text-stone-700">UNIVERSIDADE FEDERAL DE ALFENAS</div>
                <div className="text-[10px] font-sans text-stone-500">UNIFAL-MG • Instituto de Ciências da Natureza</div>
                <h3 className="text-lg font-bold uppercase text-stone-900 mt-2 font-serif">Laudo de Atividades Práticas e Certificação de Microbiologia Geral</h3>
                <div className="text-[9px] font-sans text-stone-400 uppercase tracking-wider">Emitido eletronicamente via Laboratório Virtual</div>
              </div>

              {/* Student Metadata box */}
              <div className="grid grid-cols-2 gap-4 text-xs bg-[#FAF7F2] p-4 border border-stone-200 rounded-lg font-sans">
                <div>
                  <div className="text-stone-500 text-[9px] uppercase font-bold">Discente</div>
                  <div className="font-bold text-stone-800">{studentName}</div>
                </div>
                <div>
                  <div className="text-stone-500 text-[9px] uppercase font-bold">Curso / Disciplina</div>
                  <div className="font-bold text-stone-800">Ciências Biológicas • Microbiologia Geral</div>
                </div>
                <div>
                  <div className="text-stone-500 text-[9px] uppercase font-bold">Data de Emissão</div>
                  <div className="font-bold text-stone-800">{new Date().toLocaleDateString('pt-BR')}</div>
                </div>
                <div>
                  <div className="text-stone-500 text-[9px] uppercase font-bold">Aproveitamento Acadêmico</div>
                  <div className="font-bold text-emerald-800">{quizScore.toFixed(1)} / 10.0 (Aprovado)</div>
                </div>
              </div>

              {/* Verified Experiments list */}
              <div className="space-y-3 font-sans">
                <div className="text-xs uppercase font-bold text-stone-800 border-b border-stone-200 pb-1 flex items-center">
                  <CheckCircle className="h-4.5 w-4.5 text-emerald-850 mr-1.5" />
                  Módulos de Laboratório Práticos Concluídos
                </div>

                <div className="grid grid-cols-2 gap-2 text-[10.5px]">
                  <div className="p-2.5 border border-stone-100 rounded bg-stone-50/50">
                    <strong className="text-stone-800">1. Bolor de Pão (Rhizopus stolonifer):</strong>
                    <p className="text-stone-500 mt-0.5 leading-relaxed">Fatores abióticos (umidade e temperatura) determinam a taxa de digestão enzimática e proliferação do zigomiceto.</p>
                  </div>
                  <div className="p-2.5 border border-stone-100 rounded bg-stone-50/50">
                    <strong className="text-stone-800">2. Fermentação (Saccharomyces):</strong>
                    <p className="text-stone-500 mt-0.5 leading-relaxed">Dióxido de carbono e etanol liberados na respiração anaeróbica dependendo do carboidrato assimilável e energia térmica.</p>
                  </div>
                  <div className="p-2.5 border border-stone-100 rounded bg-stone-50/50 col-span-2">
                    <strong className="text-stone-800">3. Microscopia Citológica:</strong>
                    <p className="text-stone-500 mt-0.5 leading-relaxed">Identificação morfológica de conidiocistos, esporângios, cadeias de conídios, hifas septadas e brotamentos de leveduras.</p>
                  </div>
                </div>
              </div>

              {/* Student responses review */}
              <div className="space-y-4 font-sans">
                <div className="text-xs uppercase font-bold text-stone-800 border-b border-stone-200 pb-1">
                  Revisão Teórica dos Exercícios Resolvidos
                </div>

                <div className="space-y-3 text-[10px]">
                  {quizQuestions.map((q, idx) => {
                    const isCorrect = selectedAnswers[q.id] === q.correctIdx;
                    return (
                      <div key={q.id} className="p-2.5 rounded border border-stone-200">
                        <div className="flex justify-between items-center font-bold">
                          <span>Questão {idx + 1} — {isCorrect ? '✓ Correta' : '✗ Incorreta'}</span>
                          <span className={isCorrect ? 'text-emerald-800' : 'text-rose-800'}>
                            {isCorrect ? `+${(10 / quizQuestions.length).toFixed(1)} Pontos` : '0 Pontos'}
                          </span>
                        </div>
                        <p className="text-stone-800 mt-1 font-semibold">{q.question}</p>
                        <p className="text-stone-500 mt-0.5 font-mono">
                          Sua resposta: {q.options[selectedAnswers[q.id] || 0]}
                        </p>
                        <p className="text-stone-600 mt-1 italic bg-stone-50 p-1.5 rounded text-[9px] border-l-2 border-emerald-600">
                          <strong>Gabarito Comentado:</strong> {q.explanation}
                        </p>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Signature section */}
              <div className="pt-8 border-t border-stone-200 grid grid-cols-2 gap-8 text-center text-xs font-sans">
                <div className="space-y-1 mt-6">
                  <div className="w-48 border-b border-stone-400 mx-auto" />
                  <div className="font-bold text-stone-700">{studentName}</div>
                  <div className="text-[10px] text-stone-400">Discente Praticante</div>
                </div>
                <div className="space-y-1">
                  <div className="text-[10px] italic text-emerald-800 font-bold font-serif uppercase">Documento Homologado</div>
                  <div className="font-serif font-bold text-stone-800 mt-2">Banca Examinadora UNIFAL-MG</div>
                  <div className="text-[9.5px] text-stone-500">Evânia, Helder, Raphael e Zilar</div>
                  <div className="text-[9px] text-stone-400">Membros Fundadores do Laboratório</div>
                </div>
              </div>

            </div>
          )}

        </div>

      </div>
    </div>
  );
}
