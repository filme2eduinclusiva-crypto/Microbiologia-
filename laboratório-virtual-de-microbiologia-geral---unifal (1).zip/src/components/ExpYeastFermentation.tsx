import React, { useState, useEffect } from 'react';
import { Play, RotateCcw, Flame, Info, HelpCircle, FileText, CheckCircle2 } from 'lucide-react';
import { YeastConditions } from '../types';

export default function ExpYeastFermentation() {
  const [conditions, setConditions] = useState<YeastConditions>({
    substrate: 'acucar',
    temperature: 'ambiente',
  });

  const [time, setTime] = useState(0); // in simulated minutes (0 to 30)
  const [isSimulating, setIsSimulating] = useState(false);
  const [balloonScale, setBalloonScale] = useState(1.0);
  const [balloonHeight, setBalloonHeight] = useState(0);
  const [co2Level, setCo2Level] = useState(0);
  const [bubblesCount, setBubblesCount] = useState(0);
  const [log, setLog] = useState<string[]>([]);

  // Calculate CO2 accumulation rates
  const getFermentationRate = (sub: YeastConditions['substrate'], temp: YeastConditions['temperature']) => {
    let substrateMultiplier = 0;
    if (sub === 'acucar') substrateMultiplier = 1.0;
    else if (sub === 'amido') substrateMultiplier = 0.35; // slower because complex carbohydrates need hydrolysis
    else if (sub === 'adocante') substrateMultiplier = 0.05; // non-fermentable by yeast
    else if (sub === 'controle') substrateMultiplier = 0.0; // no nutrients

    let tempMultiplier = 0;
    if (temp === 'quente') tempMultiplier = 1.5; // optimal high (around 38-40C)
    else if (temp === 'ambiente') tempMultiplier = 0.8;
    else if (temp === 'frio') tempMultiplier = 0.05; // yeast metabolism suspended

    return substrateMultiplier * tempMultiplier;
  };

  const getLogForMinutes = (mins: number, co2: number, sub: YeastConditions['substrate']) => {
    if (mins === 0) return "Minuto 0: Água morna, levedura seca ativa e o substrato selecionado são misturados no balão/tubo. Balão murcho.";
    
    if (co2 === 0) {
      return `Minuto ${mins}: Nenhuma bolha visível. As células de levedura ainda estão se reidratando e saindo da dormência.`;
    } else if (co2 < 20) {
      return `Minuto ${mins}: Pequenas bolhas de CO₂ começam a subir na solução fúngica. O balão começa a endireitar-se.`;
    } else if (co2 < 60) {
      return `Minuto ${mins}: Fermentação ativa! Liberação contínua de dióxido de carbono. O balão infla moderadamente. Odor de etanol perceptível se fosse real.`;
    } else {
      return `Minuto ${mins}: Liberação vigorosa de gás. O balão está inflado sob forte pressão interna. A espuma da fermentação sobe no bico do tubo de ensaio.`;
    }
  };

  const startSimulation = () => {
    setIsSimulating(true);
    setTime(0);
    setCo2Level(0);
    setBalloonScale(1);
    setBalloonHeight(0);
    setBubblesCount(0);
    setLog([getLogForMinutes(0, 0, conditions.substrate)]);

    let currentMin = 0;
    const rate = getFermentationRate(conditions.substrate, conditions.temperature);

    const interval = setInterval(() => {
      currentMin += 3; // Step of 3 minutes
      setTime(currentMin);

      // Accumulate CO2
      const newCo2 = Math.min(100, Math.round(currentMin * rate * 6));
      setCo2Level(newCo2);

      // Balloons properties based on CO2
      const scale = 1 + (newCo2 / 100) * 1.6;
      setBalloonScale(scale);
      setBalloonHeight(newCo2 * 0.9);
      setBubblesCount(Math.min(15, Math.ceil(rate * 10)));

      setLog(prev => [...prev, getLogForMinutes(currentMin, newCo2, conditions.substrate)]);

      if (currentMin >= 30) {
        clearInterval(interval);
        setIsSimulating(false);
      }
    }, 600);
  };

  const resetSimulation = () => {
    setTime(0);
    setCo2Level(0);
    setBalloonScale(1);
    setBalloonHeight(0);
    setBubblesCount(0);
    setLog([]);
    setIsSimulating(false);
  };

  return (
    <div className="bg-white border border-stone-200 rounded-2xl p-6 shadow-sm" id="exp-yeast-fermentation">
      <div className="border-b border-stone-200 pb-4 mb-6">
        <div className="flex items-center space-x-2">
          <span className="text-xs font-semibold px-2.5 py-1 rounded bg-emerald-50 text-emerald-800 border border-emerald-200/60">
            Fungos Unicelulares (Ascomicetos)
          </span>
          <span className="text-xs font-semibold px-2.5 py-1 rounded bg-stone-100 text-stone-700">
            Dificuldade: Médio
          </span>
        </div>
        <h2 className="text-2xl font-bold text-stone-900 mt-2">
          Experimento 2: Fermentação Alcoólica por Leveduras (Saccharomyces cerevisiae)
        </h2>
        <p className="text-sm text-stone-600 mt-1">
          Simule as taxas metabólicas da levedura de panificação alimentada com diferentes carboidratos e submetida a diferentes temperaturas térmicas.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Controls Column */}
        <div className="lg:col-span-4 flex flex-col space-y-6">
          <div className="bg-[#FAF7F2] border border-stone-200 p-5 rounded-xl">
            <h3 className="text-sm font-semibold text-stone-800 uppercase tracking-wider mb-4 flex items-center">
              <Flame className="h-4 w-4 mr-2 text-emerald-700" />
              Parâmetros da Reação
            </h3>

            {/* Substrates selection */}
            <div className="mb-5">
              <label className="text-xs font-medium text-stone-600 block mb-2">
                Substrato Nutritivo (Fonte de Energia)
              </label>
              <div className="space-y-2">
                {[
                  { id: 'acucar', label: 'Sacarose (Açúcar de cana)', desc: 'Carboidrato simples, altamente fermentável' },
                  { id: 'amido', label: 'Amido (Farinha de Trigo)', desc: 'Polissacarídeo complexo, digestão lenta' },
                  { id: 'adocante', label: 'Adoçante (Sucralose)', desc: 'Molécula artificial, não degradada' },
                  { id: 'controle', label: 'Controle (Sem alimento)', desc: 'Apenas água destilada' },
                ].map((sub) => (
                  <button
                    key={sub.id}
                    disabled={isSimulating}
                    onClick={() => setConditions(prev => ({ ...prev, substrate: sub.id as YeastConditions['substrate'] }))}
                    className={`w-full py-2.5 px-3 rounded-lg text-left text-xs font-semibold border transition-all ${
                      conditions.substrate === sub.id
                        ? 'bg-emerald-50 text-emerald-900 border-emerald-600 shadow-sm'
                        : 'bg-white text-stone-600 border-stone-200 hover:border-stone-300 hover:bg-stone-50'
                    }`}
                    id={`sub-${sub.id}`}
                  >
                    <div className="font-bold">{sub.label}</div>
                    <div className="text-[10px] text-stone-400 font-normal mt-0.5">{sub.desc}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Temperature selection */}
            <div className="mb-4">
              <label className="text-xs font-medium text-stone-600 block mb-2">
                Temperatura de Banho-Maria
              </label>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { id: 'frio', label: 'Frio (4°C)' },
                  { id: 'ambiente', label: 'Morno (25°C)' },
                  { id: 'quente', label: 'Quente (38°C)' },
                ].map((temp) => (
                  <button
                    key={temp.id}
                    disabled={isSimulating}
                    onClick={() => setConditions(prev => ({ ...prev, temperature: temp.id as YeastConditions['temperature'] }))}
                    className={`py-2 px-1 rounded-lg text-[11px] font-bold border transition-all text-center ${
                      conditions.temperature === temp.id
                        ? temp.id === 'quente'
                          ? 'bg-rose-50 text-rose-800 border-rose-300'
                          : temp.id === 'frio'
                          ? 'bg-sky-50 text-sky-800 border-sky-300'
                          : 'bg-emerald-50 text-emerald-800 border-emerald-600'
                        : 'bg-white text-stone-600 border-stone-200 hover:border-stone-300 hover:bg-stone-50'
                    }`}
                    id={`temp-yeast-${temp.id}`}
                  >
                    {temp.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex space-x-3">
            <button
              onClick={startSimulation}
              disabled={isSimulating}
              className="flex-1 py-3 px-4 rounded-xl text-sm font-bold bg-emerald-800 text-white hover:bg-emerald-700 hover:scale-[1.02] active:scale-[0.98] disabled:bg-stone-100 disabled:text-stone-400 disabled:scale-100 transition-all flex items-center justify-center space-x-2 shadow-sm"
              id="btn-iniciar-levedura"
            >
              <Play className="h-4 w-4" />
              <span>{time > 0 && time < 30 ? 'Fermentando...' : 'Iniciar Reação'}</span>
            </button>
            <button
              onClick={resetSimulation}
              disabled={isSimulating || time === 0}
              className="p-3 rounded-xl border border-stone-200 text-stone-600 hover:text-stone-900 hover:bg-stone-50 transition-all"
              title="Limpar Vidraria"
              id="btn-resetar-levedura"
            >
              <RotateCcw className="h-4 w-4" />
            </button>
          </div>

          {/* Fermentation Reaction display */}
          <div className="bg-white border border-stone-200 p-4 rounded-xl shadow-sm">
            <h4 className="text-[11px] font-bold text-stone-500 uppercase tracking-widest mb-1.5 flex items-center">
              <HelpCircle className="h-3.5 w-3.5 text-emerald-700 mr-1" /> Reação Química de Fermentação
            </h4>
            <div className="bg-[#FAF7F2] p-2.5 rounded border border-stone-200 font-mono text-[10.5px] text-center text-emerald-800 leading-relaxed">
              <span className="text-stone-600">Glicose:</span> C₆H₁₂O₆
              <div className="text-stone-500 my-0.5 font-sans">↓ Levedura (Anaerobiose) ↓</div>
              2 C₂H₅OH + 2 <span className="text-rose-700 font-bold">CO₂ ↑</span> + 2 ATP
              <div className="text-[9px] text-stone-500 mt-1 font-sans">(Álcool Etílico + Gás Carbônico + Energia)</div>
            </div>
          </div>
        </div>

        {/* Reaction Visualization Column */}
        <div className="lg:col-span-8 flex flex-col space-y-6">
          <div className="bg-[#FAF7F2] border border-stone-200 p-6 rounded-2xl flex flex-col items-center justify-center min-h-[380px] relative overflow-hidden shadow-sm">
            
            {/* Visual background grid */}
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom,rgba(16,185,129,0.04),transparent_60%)]" />
            
            {/* Dynamic Balloon and Tube Assembly */}
            <div className="relative flex flex-col items-center mt-20 mb-8 z-10">
              
              {/* Balloon */}
              <div 
                className="absolute transition-all duration-300 ease-out origin-bottom"
                style={{
                  transform: `scale(${balloonScale})`,
                  bottom: '120px', // Positioned right above the tube opening
                }}
              >
                {/* Balloon SVG */}
                <svg width="70" height="90" viewBox="0 0 70 90" className="drop-shadow-md">
                  {/* Balloon body */}
                  <path 
                    d="M 35 85 C 10 85 0 60 0 35 C 0 15 15 0 35 0 C 55 0 70 15 70 35 C 70 60 60 85 35 85 Z" 
                    fill={
                      conditions.substrate === 'acucar' 
                        ? '#ec4899' // Pink balloon for Sugar
                        : conditions.substrate === 'amido'
                        ? '#3b82f6' // Blue balloon for Amido
                        : conditions.substrate === 'adocante'
                        ? '#eab308' // Yellow balloon for Sweetener
                        : '#64748b' // Slate balloon for Control
                    } 
                    className="transition-colors duration-500"
                  />
                  {/* Balloon knot at bottom */}
                  <polygon points="30,85 40,85 35,90" fill="#334155" />
                  
                  {/* Highlights to make it 3D */}
                  <ellipse cx="20" cy="25" rx="5" ry="12" fill="#ffffff" opacity="0.25" transform="rotate(-15, 20, 25)" />
                </svg>
                
                {/* Gás pressure reading badge */}
                {co2Level > 5 && (
                  <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-white/95 text-[10px] text-stone-800 py-0.5 px-1.5 rounded-full font-mono border border-stone-200 shadow-sm scale-90">
                    {co2Level}% CO₂
                  </div>
                )}
              </div>

              {/* Test Tube */}
              <div className="w-14 h-40 bg-stone-100/30 border-2 border-stone-400/40 rounded-b-full relative overflow-hidden backdrop-blur-[2px] shadow-sm">
                {/* Fluid column inside test tube */}
                <div className="absolute bottom-0 left-0 right-0 h-20 bg-emerald-800/40 border-t border-emerald-400/40 overflow-hidden">
                  
                  {/* Liquid surface foam */}
                  {co2Level > 0 && (
                    <div className="absolute top-0 left-0 right-0 h-3 bg-white/20 flex space-x-1 overflow-hidden">
                      <div className="h-full w-2 rounded-full bg-white/50 animate-bounce" />
                      <div className="h-full w-3 rounded-full bg-white/30 animate-pulse delay-75" />
                      <div className="h-full w-1.5 rounded-full bg-white/40 animate-bounce delay-150" />
                      <div className="h-full w-4 rounded-full bg-white/20 animate-pulse delay-100" />
                      <div className="h-full w-2 rounded-full bg-white/50 animate-bounce" />
                    </div>
                  )}

                  {/* Sedimentary yeast cells at bottom */}
                  <div className="absolute bottom-0 left-0 right-0 h-4 bg-amber-900/30 blur-[1px] border-t border-amber-800/20" />

                  {/* Floating fermentation bubbles rising */}
                  {Array.from({ length: bubblesCount }).map((_, i) => {
                    const randomX = Math.floor(Math.sin(i * 123) * 16 + 20);
                    const randomDelay = (i * 0.25).toFixed(2);
                    const randomSpeed = (1.5 + Math.sin(i) * 0.5).toFixed(2);
                    const randomSize = Math.floor(Math.sin(i) * 3 + 4);
                    return (
                      <span 
                        key={i}
                        className="absolute rounded-full bg-white/70 animate-bounce"
                        style={{
                          left: `${randomX}px`,
                          bottom: '-10px',
                          width: `${randomSize}px`,
                          height: `${randomSize}px`,
                          animation: `bounce ${randomSpeed}s infinite ease-in-out`,
                          animationDelay: `${randomDelay}s`,
                          opacity: 0.6,
                        }}
                      />
                    );
                  })}
                </div>
                
                {/* Measurement scale ticks on the tube */}
                <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-4 h-0.5 bg-stone-300" />
                <div className="absolute top-2/4 left-1/2 -translate-x-1/2 w-6 h-0.5 bg-stone-300" />
                <div className="absolute top-3/4 left-1/2 -translate-x-1/2 w-4 h-0.5 bg-stone-300" />
              </div>

              {/* Lab Test Tube Stand base */}
              <div className="w-24 h-3 bg-stone-400 rounded-lg shadow-sm mt-[-6px]" />
              <div className="w-4 h-16 bg-stone-300" />
              <div className="w-32 h-4 bg-stone-200 rounded-md border border-stone-300" />
            </div>

            {/* Simulating HUD information overlay */}
            <div className="w-full max-w-md bg-white border border-stone-200 rounded-xl p-4 grid grid-cols-3 gap-2 text-center text-xs shadow-sm">
              <div className="p-2 border-r border-stone-100">
                <span className="text-stone-500 block uppercase text-[9px] font-bold tracking-wider">Cronômetro</span>
                <span className="text-stone-800 font-bold font-mono text-sm">{time} min</span>
              </div>
              <div className="p-2 border-r border-stone-100">
                <span className="text-stone-500 block uppercase text-[9px] font-bold tracking-wider">Taxa Metabólica</span>
                <span className="text-emerald-700 font-bold text-sm">
                  {getFermentationRate(conditions.substrate, conditions.temperature) > 1.0 
                    ? 'Muito Rápida' 
                    : getFermentationRate(conditions.substrate, conditions.temperature) > 0.4
                    ? 'Moderada'
                    : getFermentationRate(conditions.substrate, conditions.temperature) > 0.01
                    ? 'Lenta / Parada'
                    : 'Inativa (0%)'}
                </span>
              </div>
              <div className="p-2">
                <span className="text-stone-500 block uppercase text-[9px] font-bold tracking-wider">Espuma / Resíduo</span>
                <span className="text-rose-700 font-bold text-sm">
                  {co2Level > 60 ? 'Abundante' : co2Level > 20 ? 'Discreta' : 'Ausente'}
                </span>
              </div>
            </div>

          </div>

          {/* Diary / Lab Notebook */}
          <div className="bg-white border border-stone-200 p-5 rounded-xl shadow-sm">
            <h3 className="text-sm font-semibold text-stone-800 mb-3 flex items-center">
              <span className="bg-stone-100 text-stone-600 text-xs px-2 py-0.5 rounded-md mr-2 font-mono border border-stone-200/80">DIÁRIO</span>
              Anotações de Bioquímica Fúngica
            </h3>
            
            <div className="space-y-2.5 max-h-40 overflow-y-auto pr-2 custom-scrollbar text-xs font-mono">
              {log.length === 0 ? (
                <div className="text-stone-400 italic">Configure o tipo de açúcar e a temperatura, então ative a reação para analisar...</div>
              ) : (
                log.map((entry, idx) => (
                  <div key={idx} className="flex items-start space-x-2 border-b border-stone-100 pb-1.5 last:border-0 last:pb-0">
                    <span className="text-emerald-700 shrink-0">►</span>
                    <span className="text-stone-700 leading-relaxed">{entry}</span>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Scientific summary of substrate fermentability */}
          <div className="bg-emerald-50/40 border border-emerald-200/60 p-4 rounded-xl flex items-start space-x-3 text-xs leading-relaxed text-stone-600 shadow-sm">
            <CheckCircle2 className="h-5 w-5 text-emerald-700 shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold text-emerald-900">Discussão Científica do Resultado: </span>
              {conditions.substrate === 'acucar' && conditions.temperature === 'quente' ? (
                <span>Excelente. A sacarose é facilmente quebrada em glicose e frutose pela enzima invertase da levedura, alimentando prontamente a via glicolítica. A 38°C, a energia cinética enzimática está em seu ótimo, gerando rápida fermentação.</span>
              ) : conditions.substrate === 'amido' ? (
                <span>O amido é um grande polissacarídeo. Leveduras industriais de panificação não secretam amilases em grande quantidade para quebrar o amido em glicose livre de imediato. A fermentação ocorre de forma lenta e limitada, apenas conforme poucas enzimas e outros amidos solúveis são clivados.</span>
              ) : conditions.substrate === 'adocante' ? (
                <span>Adoçantes artificiais (como a sucralose) não possuem a conformação molecular reconhecida pelas hexocinases das leveduras. Portanto, não podem entrar na glicólise e gerar piruvato, impossibilitando a fermentação metabólica fúngica.</span>
              ) : conditions.temperature === 'frio' ? (
                <span>A baixas temperaturas (4°C), a membrana celular fúngica perde fluidez, o transporte ativo fica paralisado e as enzimas metabólicas têm sua energia de ativação severamente reduzida. A levedura sobrevive, mas entra em repouso vegetativo.</span>
              ) : (
                <span>A fermentação requer uma fonte de açúcar assimilável e temperatura propícia. O controle exibe metabolismo de subsistência de reserva interna (glicogênio próprio) que é extremamente minúsculo e incapaz de inflar o balão.</span>
              )}
            </div>
          </div>

        </div>

      </div>
    </div>
  );
}
