import React, { useState, useEffect } from 'react';
import { Play, RotateCcw, Droplets, Thermometer, Sun, Calendar, Info, CheckCircle } from 'lucide-react';
import { BreadMoldConditions } from '../types';

export default function ExpBreadMold() {
  const [conditions, setConditions] = useState<BreadMoldConditions>({
    humidity: 'umido',
    temperature: 'quente',
    light: 'escuro',
  });

  const [day, setDay] = useState(0);
  const [isSimulating, setIsSimulating] = useState(false);
  const [growthLog, setGrowthLog] = useState<string[]>([]);
  const [moldPercentage, setMoldPercentage] = useState(0);

  // Growth calculations based on conditions
  const calculateGrowthForDay = (currentDay: number, cond: BreadMoldConditions) => {
    if (currentDay === 0) return 0;
    
    // Base parameters
    const isHumid = cond.humidity === 'umido';
    const isWarm = cond.temperature === 'quente';
    const isDark = cond.light === 'escuro';

    // If cold or dry, growth is extremely minimal or zero
    if (!isHumid && !isWarm) return 0; // dry and cold: no growth
    if (!isHumid) return currentDay * 1.5; // dry but warm: tiny dusty spots (max ~10%)
    if (!isWarm) return currentDay * 0.5;  // humid but cold: very slow growth (max ~3%)

    // Humid and Warm: Optimal!
    const lightMultiplier = isDark ? 1.0 : 0.85; // fungi prefer darkness (no UV inhibition)
    const baseGrowth = [0, 5, 18, 42, 70, 92, 98, 100];
    
    return Math.min(100, Math.round(baseGrowth[currentDay] * lightMultiplier));
  };

  const getLogMessage = (currentDay: number, percentage: number) => {
    if (currentDay === 0) return "Dia 0: Fatias de pão preparadas e colocadas nas respectivas incubadoras.";
    
    if (percentage === 0) {
      return `Dia ${currentDay}: Nenhuma alteração visível na superfície do pão.`;
    } else if (percentage < 10) {
      return `Dia ${currentDay}: Pequenos pontos esbranquiçados e hifas finas (micélio) começam a aparecer na superfície (${percentage}% de cobertura).`;
    } else if (percentage < 35) {
      return `Dia ${currentDay}: Manchas acinzentadas evidentes. O micélio está se ramificando ativamente (${percentage}% de cobertura).`;
    } else if (percentage < 75) {
      return `Dia ${currentDay}: Crescimento vigoroso. Desenvolvimento de esporângios pretos na ponta das hifas, dando aspecto escuro ao bolor (${percentage}% de cobertura).`;
    } else {
      return `Dia ${currentDay}: O pão está quase totalmente coberto por uma densa colônia de Rhizopus stolonifer (${percentage}% de cobertura). Liberação intensa de esporos.`;
    }
  };

  const startSimulation = () => {
    setIsSimulating(true);
    setDay(0);
    setMoldPercentage(0);
    setGrowthLog([getLogMessage(0, 0)]);

    let currentDay = 0;
    const interval = setInterval(() => {
      currentDay += 1;
      setDay(currentDay);
      
      const pct = calculateGrowthForDay(currentDay, conditions);
      setMoldPercentage(pct);
      
      setGrowthLog(prev => [...prev, getLogMessage(currentDay, pct)]);

      if (currentDay >= 7) {
        clearInterval(interval);
        setIsSimulating(false);
      }
    }, 1000);
  };

  const resetSimulation = () => {
    setDay(0);
    setMoldPercentage(0);
    setGrowthLog([]);
    setIsSimulating(false);
  };

  // Pre-calculate growth graph values for the current configuration
  const graphData = Array.from({ length: 8 }, (_, i) => ({
    day: i,
    val: calculateGrowthForDay(i, conditions),
  }));

  return (
    <div className="bg-white border border-stone-200 rounded-2xl p-6 shadow-sm" id="exp-bread-mold">
      <div className="border-b border-stone-200 pb-4 mb-6">
        <div className="flex items-center space-x-2">
          <span className="text-xs font-semibold px-2.5 py-1 rounded bg-emerald-50 text-emerald-800 border border-emerald-200/60">
            Fungos Filamentosos (Zigomicetos)
          </span>
          <span className="text-xs font-semibold px-2.5 py-1 rounded bg-stone-100 text-stone-700">
            Dificuldade: Fácil
          </span>
        </div>
        <h2 className="text-2xl font-bold text-stone-900 mt-2">
          Experimento 1: Condições de Crescimento de Bolor de Pão (Rhizopus stolonifer)
        </h2>
        <p className="text-sm text-stone-600 mt-1">
          Investigue como fatores bióticos e abióticos (água, calor e luz) influenciam a taxa de colonização fúngica em substrato orgânico.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Interactive Controls & Configuration */}
        <div className="lg:col-span-4 flex flex-col space-y-6">
          <div className="bg-[#FAF7F2] border border-stone-200 p-5 rounded-xl">
            <h3 className="text-sm font-semibold text-stone-800 uppercase tracking-wider mb-4 flex items-center">
              <Calendar className="h-4 w-4 mr-2 text-emerald-700" />
              Variáveis Ambientais
            </h3>

            {/* Humidity */}
            <div className="mb-5">
              <label className="text-xs font-medium text-stone-600 block mb-2 flex items-center">
                <Droplets className="h-3.5 w-3.5 mr-1 text-emerald-600" /> Humidade do Substrato
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  disabled={isSimulating}
                  onClick={() => setConditions(prev => ({ ...prev, humidity: 'umido' }))}
                  className={`py-2 px-3 rounded-lg text-xs font-semibold border transition-all ${
                    conditions.humidity === 'umido'
                      ? 'bg-emerald-50 text-emerald-800 border-emerald-600'
                      : 'bg-white text-stone-500 border-stone-200 hover:border-stone-300 hover:bg-stone-50'
                  }`}
                  id="humidity-umido"
                >
                  Pão Úmido (Nutritivo)
                </button>
                <button
                  disabled={isSimulating}
                  onClick={() => setConditions(prev => ({ ...prev, humidity: 'seco' }))}
                  className={`py-2 px-3 rounded-lg text-xs font-semibold border transition-all ${
                    conditions.humidity === 'seco'
                      ? 'bg-amber-50 text-amber-800 border-amber-600'
                      : 'bg-white text-stone-500 border-stone-200 hover:border-stone-300 hover:bg-stone-50'
                  }`}
                  id="humidity-seco"
                >
                  Pão Seco (Desidratado)
                </button>
              </div>
            </div>

            {/* Temperature */}
            <div className="mb-5">
              <label className="text-xs font-medium text-stone-600 block mb-2 flex items-center">
                <Thermometer className="h-3.5 w-3.5 mr-1 text-rose-600" /> Temperatura de Incubação
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  disabled={isSimulating}
                  onClick={() => setConditions(prev => ({ ...prev, temperature: 'quente' }))}
                  className={`py-2 px-3 rounded-lg text-xs font-semibold border transition-all ${
                    conditions.temperature === 'quente'
                      ? 'bg-rose-50 text-rose-800 border-rose-300'
                      : 'bg-white text-stone-500 border-stone-200 hover:border-stone-300 hover:bg-stone-50'
                  }`}
                  id="temp-quente"
                >
                  Quente (28°C - Estufa)
                </button>
                <button
                  disabled={isSimulating}
                  onClick={() => setConditions(prev => ({ ...prev, temperature: 'frio' }))}
                  className={`py-2 px-3 rounded-lg text-xs font-semibold border transition-all ${
                    conditions.temperature === 'frio'
                      ? 'bg-sky-50 text-sky-800 border-sky-300'
                      : 'bg-white text-stone-500 border-stone-200 hover:border-stone-300 hover:bg-stone-50'
                  }`}
                  id="temp-frio"
                >
                  Frio (4°C - Geladeira)
                </button>
              </div>
            </div>

            {/* Light */}
            <div className="mb-4">
              <label className="text-xs font-medium text-stone-600 block mb-2 flex items-center">
                <Sun className="h-3.5 w-3.5 mr-1 text-amber-600" /> Exposição Luminosa
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  disabled={isSimulating}
                  onClick={() => setConditions(prev => ({ ...prev, light: 'escuro' }))}
                  className={`py-2 px-3 rounded-lg text-xs font-semibold border transition-all ${
                    conditions.light === 'escuro'
                      ? 'bg-stone-800 text-white border-stone-900'
                      : 'bg-white text-stone-500 border-stone-200 hover:border-stone-300 hover:bg-stone-50'
                  }`}
                  id="light-escuro"
                >
                  Escuro (Armário)
                </button>
                <button
                  disabled={isSimulating}
                  onClick={() => setConditions(prev => ({ ...prev, light: 'claro' }))}
                  className={`py-2 px-3 rounded-lg text-xs font-semibold border transition-all ${
                    conditions.light === 'claro'
                      ? 'bg-amber-50 text-amber-800 border-amber-400'
                      : 'bg-white text-stone-500 border-stone-200 hover:border-stone-300 hover:bg-stone-50'
                  }`}
                  id="light-claro"
                >
                  Claro (Luz Direta)
                </button>
              </div>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex space-x-3">
            <button
              onClick={startSimulation}
              disabled={isSimulating}
              className="flex-1 py-3 px-4 rounded-xl text-sm font-bold bg-emerald-800 text-white hover:bg-emerald-700 hover:scale-[1.02] active:scale-[0.98] disabled:bg-stone-100 disabled:text-stone-400 disabled:scale-100 transition-all flex items-center justify-center space-x-2 shadow-sm"
              id="btn-iniciar-bolor"
            >
              <Play className="h-4 w-4" />
              <span>{day > 0 && day < 7 ? 'Simulando...' : 'Iniciar Cultivo'}</span>
            </button>
            <button
              onClick={resetSimulation}
              disabled={isSimulating || day === 0}
              className="p-3 rounded-xl border border-stone-200 text-stone-600 hover:text-stone-900 hover:bg-stone-50 transition-all"
              title="Limpar Placa"
              id="btn-resetar-bolor"
            >
              <RotateCcw className="h-4 w-4" />
            </button>
          </div>

          {/* Scientific Info Box */}
          <div className="bg-emerald-50/40 border border-emerald-200/60 p-4 rounded-xl text-xs text-stone-600 leading-relaxed">
            <div className="flex items-center text-emerald-800 font-semibold mb-1.5">
              <Info className="h-4 w-4 mr-1 text-emerald-700" />
              Você sabia?
            </div>
            Os fungos são heterotróficos por absorção e não realizam fotossíntese. Embora prefiram locais escuros para evitar ressecamento e radiação ultravioleta nociva, a luz direta afeta principalmente sua esporulação, não sua sobrevivência direta, desde que haja humidade.
          </div>
        </div>

        {/* Center/Right Column: Bread Petri Dish Visualizer */}
        <div className="lg:col-span-8 flex flex-col space-y-6">
          <div className="bg-[#FAF7F2] border border-stone-200 p-6 rounded-2xl flex flex-col md:flex-row items-center gap-8 shadow-sm">
            
            {/* The Visual Bread Slice */}
            <div className="relative w-64 h-64 bg-[#FAF7F2] border-2 border-stone-200 rounded-full flex items-center justify-center shadow-md overflow-hidden shrink-0 group">
              {/* Petri dish outline */}
              <div className="absolute inset-2 border-4 border-stone-300/40 rounded-full pointer-events-none" />
              
              {/* Bread Slice SVG */}
              <svg viewBox="0 0 100 100" className="w-48 h-48 drop-shadow relative z-10 transition-transform duration-500 group-hover:scale-105">
                {/* Crust */}
                <path d="M 20,40 C 20,20 80,20 80,40 C 85,60 85,85 80,85 C 40,88 20,85 20,85 Z" fill="#9e693b" />
                {/* Crumb */}
                <path d="M 23,41 C 23,24 77,24 77,41 C 81,58 81,81 76,81 C 40,84 24,81 23,81 Z" fill="#f5dec6" />
                
                {/* Yeast texture / holes */}
                <circle cx="35" cy="40" r="1.5" fill="#e8cbaf" />
                <circle cx="45" cy="35" r="2" fill="#e8cbaf" />
                <circle cx="65" cy="42" r="1.5" fill="#e8cbaf" />
                <circle cx="55" cy="50" r="2.5" fill="#e8cbaf" />
                <circle cx="32" cy="62" r="2" fill="#e8cbaf" />
                <circle cx="60" cy="68" r="1.5" fill="#e8cbaf" />
                <circle cx="45" cy="72" r="2" fill="#e8cbaf" />

                {/* Mold Overlays (Rhizopus) based on moldPercentage */}
                {moldPercentage > 0 && (
                  <g opacity={moldPercentage / 100}>
                    {/* Level 1: Whitish mold bases (micélio) */}
                    <path d="M 28,45 C 32,38 45,40 48,45 C 50,52 35,55 28,45" fill="#eceff1" opacity="0.85" />
                    <path d="M 52,60 C 58,55 70,58 68,65 C 65,72 48,70 52,60" fill="#eceff1" opacity="0.85" />
                    <path d="M 35,68 C 40,65 52,68 50,75 C 45,78 32,75 35,68" fill="#eceff1" opacity="0.85" />
                    
                    {/* Level 2: Fuzzy Grey Centers */}
                    {moldPercentage > 15 && (
                      <>
                        <circle cx="38" cy="44" r="8" fill="#b0bec5" opacity="0.9" />
                        <circle cx="60" cy="62" r="9" fill="#b0bec5" opacity="0.9" />
                        <circle cx="43" cy="71" r="7" fill="#b0bec5" opacity="0.9" />
                        <path d="M 40,30 C 50,28 65,30 62,38 C 55,42 38,38 40,30" fill="#e2e8f0" opacity="0.8" />
                      </>
                    )}

                    {/* Level 3: Dark Sporangia Spots (Black mold stage) */}
                    {moldPercentage > 40 && (
                      <>
                        {/* Spores cluster 1 */}
                        <circle cx="36" cy="42" r="4" fill="#374151" />
                        <circle cx="40" cy="46" r="3" fill="#1f2937" />
                        <circle cx="38" cy="45" r="1" fill="#111827" />
                        
                        {/* Spores cluster 2 */}
                        <circle cx="58" cy="60" r="5" fill="#374151" />
                        <circle cx="62" cy="64" r="4" fill="#1f2937" />
                        <circle cx="59" cy="63" r="2.5" fill="#111827" />

                        {/* Spores cluster 3 */}
                        <circle cx="44" cy="72" r="4.5" fill="#374151" />
                        <circle cx="42" cy="69" r="3" fill="#111827" />

                        {/* Connecting black dusty dots */}
                        <circle cx="48" cy="33" r="2" fill="#475569" />
                        <circle cx="54" cy="36" r="3.5" fill="#334155" />
                        <circle cx="59" cy="32" r="1.5" fill="#1e293b" />
                      </>
                    )}

                    {/* Level 4: Complete overgrowth at high percentages */}
                    {moldPercentage > 75 && (
                      <g>
                        {/* Denser overlay */}
                        <path d="M 25,35 C 40,25 70,25 75,35 C 80,55 80,75 75,78 C 45,82 25,78 25,75 Z" fill="#1e293b" opacity="0.75" />
                        {/* Extra tiny black dots all over */}
                        <circle cx="30" cy="50" r="1.5" fill="#090d16" />
                        <circle cx="70" cy="50" r="1" fill="#090d16" />
                        <circle cx="50" cy="55" r="2" fill="#090d16" />
                        <circle cx="45" cy="45" r="1.5" fill="#090d16" />
                        <circle cx="55" cy="48" r="1.8" fill="#090d16" />
                        <circle cx="65" cy="55" r="1.2" fill="#090d16" />
                        <circle cx="38" cy="60" r="2" fill="#090d16" />
                        <circle cx="48" cy="65" r="1.5" fill="#090d16" />
                        <circle cx="52" cy="38" r="1.3" fill="#090d16" />
                      </g>
                    )}
                  </g>
                )}
              </svg>

              {/* Status Badge overlay */}
              <div className="absolute bottom-4 z-20 bg-white/95 border border-stone-200 text-stone-700 text-xs py-1 px-3 rounded-full flex items-center space-x-1.5 shadow-sm">
                <span className="h-2.5 w-2.5 rounded-full bg-emerald-600" />
                <span className="font-mono">Pão de Teste</span>
              </div>
            </div>

            {/* Live Stats Panel */}
            <div className="flex-1 w-full space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-white border border-stone-200 p-3 rounded-lg text-center shadow-sm">
                  <div className="text-[10px] uppercase font-bold tracking-wider text-stone-500">Tempo Decorrido</div>
                  <div className="text-xl font-bold text-stone-800 mt-1 flex items-center justify-center space-x-1.5">
                    <Calendar className="h-5 w-5 text-emerald-700" />
                    <span>Dia {day} / 7</span>
                  </div>
                </div>
                <div className="bg-white border border-stone-200 p-3 rounded-lg text-center shadow-sm">
                  <div className="text-[10px] uppercase font-bold tracking-wider text-stone-500">Cobertura de Bolor</div>
                  <div className="text-xl font-bold text-stone-850 mt-1">
                    <span className={`font-mono ${moldPercentage > 50 ? 'text-rose-700' : 'text-emerald-700'}`}>
                      {moldPercentage}%
                    </span>
                  </div>
                </div>
              </div>

              {/* Progress Bar */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs font-semibold text-stone-500">
                  <span>Invasão por Micélio</span>
                  <span>{moldPercentage}%</span>
                </div>
                <div className="w-full bg-stone-100 rounded-full h-3.5 border border-stone-200 overflow-hidden">
                  <div
                    className="bg-gradient-to-r from-emerald-600 via-amber-500 to-rose-600 h-full transition-all duration-300"
                    style={{ width: `${moldPercentage}%` }}
                  />
                </div>
              </div>

              {/* Conditions Feedback badge */}
              <div className="bg-white border border-stone-200 p-3 rounded-xl flex items-start space-x-2 shadow-sm">
                <CheckCircle className={`h-4.5 w-4.5 shrink-0 mt-0.5 ${moldPercentage > 40 ? 'text-emerald-600' : 'text-stone-400'}`} />
                <div className="text-xs">
                  <span className="font-semibold text-stone-700">Análise de Crescimento: </span>
                  {conditions.humidity === 'seco' ? (
                    <span className="text-amber-700">Sem humidade livre, os esporos não conseguem germinar. A parede do esporo necessita de hidratação para iniciar o metabolismo celular.</span>
                  ) : conditions.temperature === 'frio' ? (
                    <span className="text-sky-700">A baixa temperatura (4°C) atrasa drasticamente as taxas enzimáticas de digestão do fungo, mantendo-o em estado latente.</span>
                  ) : (
                    <span className="text-emerald-700">Condições ideais de humidade e temperatura. O micélio vegetativo secreta enzimas digestivas no amido do pão, digerindo-o extracelularmente e absorvendo nutrientes com rapidez.</span>
                  )}
                </div>
              </div>
            </div>

          </div>

          {/* Diário de Campo / Log de crescimento */}
          <div className="bg-white border border-stone-200 p-5 rounded-xl shadow-sm">
            <h3 className="text-sm font-semibold text-stone-800 mb-3 flex items-center">
              <span className="bg-stone-100 text-stone-600 text-xs px-2 py-0.5 rounded-md mr-2 font-mono border border-stone-200/80">DIÁRIO</span>
              Diário Fúngico do Laboratório (Caderno de Campo)
            </h3>
            
            <div className="space-y-2.5 max-h-40 overflow-y-auto pr-2 custom-scrollbar text-xs font-mono">
              {growthLog.length === 0 ? (
                <div className="text-stone-400 italic">Configure as variáveis ambientais e clique em "Iniciar Cultivo" para preencher o caderno...</div>
              ) : (
                growthLog.map((log, idx) => (
                  <div key={idx} className="flex items-start space-x-2 border-b border-stone-100 pb-1.5 last:border-0 last:pb-0">
                    <span className="text-emerald-700 shrink-0">►</span>
                    <span className="text-stone-700 leading-relaxed">{log}</span>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Mini-Graph of Coverage Growth over 7 days */}
          <div className="bg-white border border-stone-200 p-5 rounded-xl shadow-sm">
            <h4 className="text-xs font-bold text-stone-500 uppercase tracking-widest mb-3">Gráfico Científico: Curva de Crescimento</h4>
            <div className="h-28 flex items-end justify-between px-4 pt-4 border-b border-l border-stone-200 relative">
              
              {/* Grid Lines */}
              <div className="absolute top-0 left-0 right-0 h-px bg-stone-100" />
              <div className="absolute top-1/2 left-0 right-0 h-px bg-stone-100" />
              
              {/* Plotting Bars representing the predicted curve */}
              {graphData.map((d, idx) => {
                const isActive = day >= d.day;
                return (
                  <div key={idx} className="flex flex-col items-center flex-1 group relative">
                    {/* Tooltip on hover */}
                    <div className="absolute bottom-full mb-1 opacity-0 group-hover:opacity-100 transition-opacity bg-stone-800 text-white text-[10px] font-mono py-0.5 px-1.5 rounded shadow pointer-events-none z-30">
                      {d.val}%
                    </div>
                    {/* The bar */}
                    <div 
                      className={`w-4 sm:w-6 rounded-t-sm transition-all duration-500 ${
                        isActive 
                          ? 'bg-emerald-700' 
                          : 'bg-stone-100'
                      }`}
                      style={{ height: `${Math.max(4, d.val)}px` }}
                    />
                    <span className="text-[10px] text-stone-500 font-mono mt-1.5">D{d.day}</span>
                  </div>
                );
              })}
              
              {/* Y-axis labels */}
              <div className="absolute right-2 top-0 text-[8px] text-stone-400 font-mono">100% (Saturação)</div>
              <div className="absolute right-2 top-1/2 text-[8px] text-stone-400 font-mono">50%</div>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
}
