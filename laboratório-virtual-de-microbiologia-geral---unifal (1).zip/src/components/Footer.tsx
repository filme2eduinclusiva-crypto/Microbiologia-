import React from 'react';
import { Heart, GraduationCap, Users, Calendar } from 'lucide-react';

export default function Footer() {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-[#142A1C] border-t border-[#0e1d13] text-[#A7D7C1] mt-12 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-center pb-6 border-b border-[#1C3A27]/60">
          
          {/* Institution Info */}
          <div className="text-center md:text-left">
            <h3 className="text-sm font-semibold text-white tracking-wider uppercase mb-2">
              Universidade Federal de Alfenas
            </h3>
            <p className="text-xs text-emerald-200/70 leading-relaxed max-w-sm mx-auto md:mx-0">
              UNIFAL-MG — Instituto de Ciências da Natureza. Desenvolvido para fins acadêmicos e pedagógicos no ensino de micologia e microbiologia.
            </p>
          </div>

          {/* Development Team Credits */}
          <div className="text-center bg-[#0e1d13]/60 border border-[#1C3A27] p-4 rounded-xl shadow-inner">
            <div className="flex items-center justify-center space-x-1 text-xs font-semibold uppercase text-[#A7D7C1] tracking-wider mb-2">
              <Users className="h-4 w-4 mr-1 text-emerald-400" />
              Desenvolvido por
            </div>
            <div className="text-sm font-bold text-white flex flex-wrap justify-center gap-x-2 gap-y-1">
              <span className="hover:text-emerald-300 transition-colors">Evânia</span>
              <span className="text-emerald-600">•</span>
              <span className="hover:text-emerald-300 transition-colors">Helder</span>
              <span className="text-emerald-600">•</span>
              <span className="hover:text-emerald-300 transition-colors">Raphael</span>
              <span className="text-emerald-600">•</span>
              <span className="hover:text-emerald-300 transition-colors">Zilar</span>
            </div>
          </div>

          {/* Academic Info */}
          <div className="text-center md:text-right text-xs text-emerald-200/70 space-y-1">
            <div className="flex items-center justify-center md:justify-end space-x-1 text-[#A7D7C1] font-medium">
              <GraduationCap className="h-4 w-4 text-emerald-400" />
              <span>Disciplina de Microbiologia Geral</span>
            </div>
            <p>Curso de Ciências Biológicas</p>
            <div className="flex items-center justify-center md:justify-end space-x-1 text-emerald-500 mt-2">
              <Calendar className="h-3 w-3" />
              <span>Alfenas - MG • {currentYear}</span>
            </div>
          </div>

        </div>

        {/* License & Copy */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between text-[11px] text-emerald-200/50">
          <p className="text-center sm:text-left">
            &copy; {currentYear} UNIFAL-MG. Todos os direitos reservados para fins de ensino.
          </p>
          <p className="flex items-center mt-2 sm:mt-0">
            Tecnologia de Laboratório Virtual Interativo
            <Heart className="h-3 w-3 text-emerald-400 mx-1 fill-emerald-400" />
            para o ensino de Ciências
          </p>
        </div>
      </div>
    </footer>
  );
}
