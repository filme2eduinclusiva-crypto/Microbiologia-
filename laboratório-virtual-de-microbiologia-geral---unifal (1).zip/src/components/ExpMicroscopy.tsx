import React, { useState } from 'react';
import { Microscope, Info, RotateCcw, ZoomIn, ZoomOut, Eye, HelpCircle, AlertTriangle } from 'lucide-react';
import { MicroscopeState } from '../types';

export default function ExpMicroscopy() {
  const [state, setState] = useState<MicroscopeState>({
    slideId: 'rhizopus',
    zoom: 10,
    focus: 15, // Starts unfocused so the student has to adjust it!
    lightIntensity: 40,
  });

  const [discoveredStructures, setDiscoveredStructures] = useState<string[]>([]);

  const slides = [
    {
      id: 'rhizopus' as const,
      name: 'Rhizopus stolonifer (Bolor)',
      phylum: 'Mucoromycota (Antigo Zygomycota)',
      structures: ['Esporângio', 'Esporângiosporos', 'Columela', 'Esporangióforo', 'Rizoides'],
      description: 'Estruturas fúngicas assexuadas de esporulação. Os esporângios contêm milhares de esporângiosporos formados por clivagem citoplasmática ao redor da columela central.',
      tips: 'Procure uma grande cabeça redonda escura sustentada por uma hifa vertical.',
    },
    {
      id: 'aspergillus' as const,
      name: 'Aspergillus niger (Orelha-de-padre)',
      phylum: 'Ascomycota',
      structures: ['Conidióforo', 'Vesícula', 'Fiálides', 'Conídios'],
      description: 'Fungo filamentoso caracterizado por cabeças conidiais radiadas. Os conídios pretos nascem em cadeias a partir de células especializadas chamadas fiálides, cobrindo a vesícula globosa.',
      tips: 'Observe a cabeça em formato de dente-de-leão ou chuveiro esférico com conídios pretos.',
    },
    {
      id: 'penicillium' as const,
      name: 'Penicillium chrysogenum (Mofo Azul)',
      phylum: 'Ascomycota',
      structures: ['Conidióforo', 'Métricas / Ramificações', 'Fiálides em Pincel', 'Conídios em Cadeia'],
      description: 'Fungo produtor do primeiro antibiótico natural descoberto (penicilina). O conidióforo possui ramificações que lembram a anatomia de um pincel ou vassoura.',
      tips: 'Ajuste bem o foco fino para visualizar a estrutura que parece uma vassoura de hifas.',
    },
    {
      id: 'yeast' as const,
      name: 'Saccharomyces cerevisiae (Levedura)',
      phylum: 'Ascomycota (Unicelular)',
      structures: ['Célula Leveduriforme', 'Brotamento / Gemulação', 'Vacúolo de Reserva', 'Cicatriz'],
      description: 'Organismo eucariótico unicelular amplamente empregado na panificação e cervejaria. Reproduz-se assexuadamente por brotamento ou gemulação lateral.',
      tips: 'Aumente o zoom para 40x ou 100x; leveduras são muito pequenas e aparecem como células ovóides isoladas ou brotando.',
    },
  ];

  const activeSlide = slides.find(s => s.id === state.slideId) || slides[0];

  // Helper calculations for visual rendering
  const isFocused = state.focus >= 44 && state.focus <= 56;
  const isPartiallyFocused = state.focus >= 30 && state.focus <= 70;
  
  // High zoom and low focus blur multiplier
  const focusDiff = Math.abs(state.focus - 50);
  const blurAmount = Math.max(0, (focusDiff * 0.4) - 0.5);

  // Light effects (optimum between 50 and 80)
  const brightness = state.lightIntensity / 65; 
  const contrast = state.lightIntensity > 85 ? 0.6 : state.lightIntensity < 25 ? 0.5 : 1.0;

  const handleDiscoverStructure = (struct: string) => {
    if (!discoveredStructures.includes(struct)) {
      setDiscoveredStructures(prev => [...prev, struct]);
    }
  };

  const handleResetFocus = () => {
    setState(prev => ({ ...prev, focus: 15, lightIntensity: 45 }));
    setDiscoveredStructures([]);
  };

  return (
    <div className="bg-white border border-stone-200 rounded-2xl p-6 shadow-sm" id="exp-microscopy">
      <div className="border-b border-stone-200 pb-4 mb-6">
        <div className="flex items-center space-x-2">
          <span className="text-xs font-semibold px-2.5 py-1 rounded bg-emerald-50 text-emerald-800 border border-emerald-200/60">
            Microscopia Ótica Virtual
          </span>
          <span className="text-xs font-semibold px-2.5 py-1 rounded bg-stone-100 text-stone-700">
            Dificuldade: Difícil
          </span>
        </div>
        <h2 className="text-2xl font-bold text-stone-900 mt-2">
          Experimento 3: Citologia e Estruturas de Reprodução em Microscópio Ótico
        </h2>
        <p className="text-sm text-stone-600 mt-1">
          Posicione as lâminas, ligue a fonte de luz e ajuste os botões micrométrico e macrométrico para revelar e identificar os micélios e conídios.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Slide Selector & Focus Sliders */}
        <div className="lg:col-span-4 flex flex-col space-y-6">
          
          {/* Lâminas Preparadas Box */}
          <div className="bg-[#FAF7F2] border border-stone-200 p-5 rounded-xl">
            <h3 className="text-sm font-semibold text-stone-800 mb-3 flex items-center">
              <Microscope className="h-4.5 w-4.5 mr-2 text-emerald-700" />
              Lâminas Histológicas Preparadas
            </h3>
            
            <div className="space-y-2">
              {slides.map((s) => (
                <button
                  key={s.id}
                  onClick={() => {
                    setState(prev => ({ ...prev, slideId: s.id, focus: 12 + Math.floor(Math.random() * 15) }));
                    setDiscoveredStructures([]);
                  }}
                  className={`w-full py-2.5 px-3 rounded-lg text-left transition-all border ${
                    state.slideId === s.id
                      ? 'bg-emerald-50 border-emerald-600 text-emerald-900 font-semibold'
                      : 'bg-white border-stone-200 text-stone-600 hover:border-stone-300 hover:bg-stone-50'
                  }`}
                  id={`slide-${s.id}`}
                >
                  <div className="text-xs font-bold">{s.name}</div>
                  <div className="text-[10px] text-stone-500 font-medium mt-0.5">{s.phylum}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Microscope adjustment knobs */}
          <div className="bg-[#FAF7F2] border border-stone-200 p-5 rounded-xl space-y-5">
            <h3 className="text-sm font-semibold text-stone-800 uppercase tracking-wider mb-2">
              Controles do Estativo
            </h3>

            {/* Objective lens */}
            <div>
              <label className="text-[11px] font-bold text-stone-500 uppercase tracking-wider block mb-2">
                Lente Objetiva (Ampliação)
              </label>
              <div className="grid grid-cols-4 gap-1.5">
                {([4, 10, 40, 100] as const).map((z) => (
                  <button
                    key={z}
                    onClick={() => setState(prev => ({ ...prev, zoom: z }))}
                    className={`py-1.5 px-1 rounded-md text-xs font-bold border transition-all text-center ${
                      state.zoom === z
                        ? 'bg-emerald-800 text-white border-emerald-700'
                        : 'bg-white text-stone-600 border-stone-200 hover:border-stone-300'
                    }`}
                    id={`zoom-obj-${z}`}
                  >
                    {z}x
                  </button>
                ))}
              </div>
            </div>

            {/* Macrometric/Micrometric (Focus Slider) */}
            <div>
              <div className="flex justify-between items-center mb-1.5">
                <label className="text-[11px] font-bold text-stone-500 uppercase tracking-wider">
                  Botão de Foco (Fino/Grosso)
                </label>
                <span className={`text-[10px] px-1.5 py-0.5 rounded font-mono font-bold uppercase ${
                  isFocused 
                    ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' 
                    : isPartiallyFocused 
                    ? 'bg-amber-50 text-amber-800 border border-amber-200' 
                    : 'bg-rose-50 text-rose-800 border border-rose-200'
                }`}>
                  {isFocused ? 'Foco Perfeito' : isPartiallyFocused ? 'Foco Próximo' : 'Desfocado'}
                </span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={state.focus}
                onChange={(e) => setState(prev => ({ ...prev, focus: Number(e.target.value) }))}
                className="w-full accent-emerald-800 cursor-pointer h-2 bg-stone-200 rounded-lg appearance-none"
                id="foco-slider"
              />
              <div className="flex justify-between text-[9px] text-stone-500 font-mono mt-1">
                <span>0 (Abaixo)</span>
                <span>Ótimo (~50)</span>
                <span>100 (Acima)</span>
              </div>
            </div>

            {/* Light Source Intensity */}
            <div>
              <div className="flex justify-between items-center mb-1.5">
                <label className="text-[11px] font-bold text-stone-500 uppercase tracking-wider">
                  Intensidade da Luz (Diafragma)
                </label>
                <span className="text-[10px] font-mono text-stone-600 font-bold">{state.lightIntensity}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={state.lightIntensity}
                onChange={(e) => setState(prev => ({ ...prev, lightIntensity: Number(e.target.value) }))}
                className="w-full accent-amber-600 cursor-pointer h-2 bg-stone-200 rounded-lg appearance-none"
                id="luz-slider"
              />
              <div className="flex justify-between text-[9px] text-stone-500 font-mono mt-1">
                <span>0 (Escuro)</span>
                <span>Ótimo (~70)</span>
                <span>100 (Saturação)</span>
              </div>
            </div>

            <button
              onClick={handleResetFocus}
              className="w-full py-2 bg-white hover:bg-stone-50 text-stone-600 hover:text-stone-850 rounded-lg text-xs font-semibold border border-stone-200 shadow-xs transition-colors flex items-center justify-center space-x-1.5"
              id="btn-recolocar-lamina"
            >
              <RotateCcw className="h-3.5 w-3.5" />
              <span>Desajustar Lâmina</span>
            </button>
          </div>

          {/* Tips box */}
          <div className="bg-emerald-50/40 border border-emerald-200/60 p-4 rounded-xl text-xs text-stone-600 leading-relaxed">
            <div className="flex items-center text-emerald-800 font-semibold mb-1.5">
              <Eye className="h-4 w-4 mr-1 text-emerald-700" />
              Dica de Ajuste:
            </div>
            {activeSlide.tips}
          </div>

        </div>

        {/* Microscope Viewport Screen Column */}
        <div className="lg:col-span-8 flex flex-col space-y-6">
          <div className="bg-[#FAF7F2] border border-stone-200 p-6 rounded-2xl flex flex-col items-center justify-center relative min-h-[440px] shadow-sm">
            
            {/* Warning if lights are too low or too high */}
            {state.lightIntensity < 15 && (
              <div className="absolute top-4 left-4 right-4 z-30 bg-rose-50 border border-rose-200 p-2.5 rounded-lg text-xs text-rose-850 flex items-center space-x-2 shadow-sm">
                <AlertTriangle className="h-4.5 w-4.5 shrink-0 text-rose-600 animate-pulse" />
                <span>O campo ótico está muito escuro. Aumente a intensidade luminosa no diafragma para visualizar o material histológico.</span>
              </div>
            )}
            {state.lightIntensity > 90 && (
              <div className="absolute top-4 left-4 right-4 z-30 bg-amber-50 border border-amber-200 p-2.5 rounded-lg text-xs text-amber-850 flex items-center space-x-2 shadow-sm">
                <AlertTriangle className="h-4.5 w-4.5 shrink-0 text-amber-600 animate-pulse" />
                <span>Luz excessiva! O campo ótico está saturado por brilho. Reduza o diafragma para aumentar o contraste celular.</span>
              </div>
            )}

            {/* Circular Field of View (The Ocular lens field) */}
            <div className="relative w-80 h-80 sm:w-96 sm:h-96 rounded-full border-8 border-stone-900 bg-stone-950 shadow-2xl overflow-hidden flex items-center justify-center select-none">
              
              {/* Ocular Reticle Grid Overlay (just like real microscope oculars) */}
              <div className="absolute inset-0 pointer-events-none border border-white/5 rounded-full z-20" />
              <div className="absolute top-1/2 left-0 right-0 h-[0.5px] bg-white/10 pointer-events-none z-20" />
              <div className="absolute left-1/2 top-0 bottom-0 w-[0.5px] bg-white/10 pointer-events-none z-20" />
              <div className="absolute inset-[30%] border border-white/5 rounded-full pointer-events-none z-20" />
              
              {/* Actual fungal visualization */}
              <div 
                className="w-full h-full relative transition-all duration-300 flex items-center justify-center bg-sky-100/5"
                style={{
                  filter: `blur(${blurAmount}px) brightness(${brightness}) contrast(${contrast})`,
                  transform: `scale(${1 + (state.zoom / 150)})`,
                }}
              >
                
                {/* 1. RHIZOPUS SLIDE */}
                {state.slideId === 'rhizopus' && (
                  <svg viewBox="0 0 100 100" className="w-4/5 h-4/5 text-purple-700/80">
                    {/* Background tint (stained with Lactophenol Cotton Blue) */}
                    <circle cx="50" cy="50" r="48" fill="#e0f2fe" opacity="0.15" />
                    
                    {/* Rhizoids at the base */}
                    <path d="M 15,90 Q 20,70 30,75 T 45,80 Q 42,92 30,95" fill="none" stroke="currentColor" strokeWidth="1" strokeDasharray="1,1" />
                    <path d="M 30,85 L 25,99 M 32,85 L 35,98 M 31,85 L 30,97" stroke="currentColor" strokeWidth="0.8" />
                    
                    {/* Sporangiophores (Vertical hyphae stalks) */}
                    <path d="M 31,85 Q 28,60 35,35" fill="none" stroke="currentColor" strokeWidth="1.5" />
                    <path d="M 31,85 Q 45,70 55,42" fill="none" stroke="currentColor" strokeWidth="1.2" />

                    {/* Stalk 1 detail (Sporangium and columella) */}
                    {/* Columella inside */}
                    <path d="M 32,36 C 30,28 40,28 38,36 Z" fill="#9333ea" opacity="0.3" />
                    {/* Sporangium outer shell */}
                    <circle cx="35" cy="30" r="8" fill="none" stroke="currentColor" strokeWidth="1" />
                    <circle cx="35" cy="30" r="7.5" fill="#581c87" opacity="0.6" />
                    
                    {/* Stalk 2 detail */}
                    <circle cx="56" cy="38" r="6" fill="#6b21a8" opacity="0.75" />
                    <circle cx="56" cy="38" r="6.2" fill="none" stroke="currentColor" strokeWidth="0.8" />
                    
                    {/* Scattered spores around */}
                    <circle cx="20" cy="30" r="1" fill="currentColor" />
                    <circle cx="24" cy="22" r="0.8" fill="currentColor" />
                    <circle cx="48" cy="25" r="1.1" fill="currentColor" />
                    <circle cx="45" cy="40" r="0.9" fill="currentColor" />
                    <circle cx="65" cy="45" r="1" fill="currentColor" />
                    <circle cx="50" cy="55" r="0.8" fill="currentColor" />
                    <circle cx="32" cy="58" r="1" fill="currentColor" />

                    {/* Text labels triggered when focused */}
                    {isFocused && (
                      <g className="animate-fade-in text-[5px] font-sans font-semibold text-indigo-900 fill-indigo-950">
                        {/* Label Sporangium */}
                        <line x1="35" y1="22" x2="22" y2="15" stroke="#4f46e5" strokeWidth="0.3" />
                        <text x="10" y="14" onClick={() => handleDiscoverStructure('Esporângio')} className="cursor-pointer hover:fill-purple-600">Esporângio [clique]</text>
                        
                        {/* Label Sporangiophores */}
                        <line x1="29" y1="58" x2="16" y2="52" stroke="#4f46e5" strokeWidth="0.3" />
                        <text x="2" y="50" onClick={() => handleDiscoverStructure('Esporangióforo')} className="cursor-pointer hover:fill-purple-600">Esporangióforo</text>
                        
                        {/* Label Rizoides */}
                        <line x1="30" y1="92" x2="45" y2="92" stroke="#4f46e5" strokeWidth="0.3" />
                        <text x="47" y="93" onClick={() => handleDiscoverStructure('Rizoides')} className="cursor-pointer hover:fill-purple-600">Rizoides (âncoras)</text>
                      </g>
                    )}
                  </svg>
                )}

                {/* 2. ASPERGILLUS SLIDE */}
                {state.slideId === 'aspergillus' && (
                  <svg viewBox="0 0 100 100" className="w-4/5 h-4/5 text-emerald-800/90">
                    <circle cx="50" cy="50" r="48" fill="#e0f2fe" opacity="0.15" />
                    
                    {/* Septate Hyphae at bottom */}
                    <path d="M 10,80 L 90,75" stroke="currentColor" strokeWidth="1" />
                    <line x1="35" y1="78.5" x2="36" y2="73.5" stroke="currentColor" strokeWidth="0.5" />
                    <line x1="65" y1="76.5" x2="66" y2="71.5" stroke="currentColor" strokeWidth="0.5" />

                    {/* Long Conidiophore rising */}
                    <path d="M 45,76 Q 40,48 48,28" fill="none" stroke="currentColor" strokeWidth="1.4" />
                    
                    {/* Large Aspergillus vesicle head */}
                    <circle cx="48" cy="28" r="6" fill="#064e3b" opacity="0.3" />
                    <circle cx="48" cy="28" r="5" fill="currentColor" />

                    {/* Phialides (sterigmata) radiating from vesicle */}
                    {Array.from({ length: 16 }).map((_, i) => {
                      const angle = (i * 360) / 16;
                      const rad = (angle * Math.PI) / 180;
                      const x1 = 48 + Math.cos(rad) * 5;
                      const y1 = 28 + Math.sin(rad) * 5;
                      const x2 = 48 + Math.cos(rad) * 9;
                      const y2 = 28 + Math.sin(rad) * 9;
                      return (
                        <g key={i}>
                          <line x1={x1} y1={y1} x2={x2} y2={y2} stroke="currentColor" strokeWidth="0.9" />
                          {/* Chain of conidiospores on top */}
                          <circle cx={x2 + Math.cos(rad) * 2.2} cy={y2 + Math.sin(rad) * 2.2} r="1.1" fill="#047857" />
                          <circle cx={x2 + Math.cos(rad) * 4.5} cy={y2 + Math.sin(rad) * 4.5} r="0.9" fill="#059669" />
                        </g>
                      );
                    })}

                    {isFocused && (
                      <g className="animate-fade-in text-[5px] font-sans font-semibold text-emerald-950 fill-emerald-950">
                        {/* Vesicle */}
                        <line x1="48" y1="28" x2="70" y2="28" stroke="#059669" strokeWidth="0.3" />
                        <text x="72" y="29.5" onClick={() => handleDiscoverStructure('Vesícula')} className="cursor-pointer hover:fill-emerald-600">Vesícula inflada</text>
                        
                        {/* Conidiospores */}
                        <line x1="60" y1="20" x2="72" y2="12" stroke="#059669" strokeWidth="0.3" />
                        <text x="74" y="13" onClick={() => handleDiscoverStructure('Conídios')} className="cursor-pointer hover:fill-emerald-600">Conídios (Esporos)</text>
                        
                        {/* Conidiophore */}
                        <line x1="43" y1="55" x2="25" y2="55" stroke="#059669" strokeWidth="0.3" />
                        <text x="5" y="56" onClick={() => handleDiscoverStructure('Conidióforo')} className="cursor-pointer hover:fill-emerald-600">Conidióforo</text>
                      </g>
                    )}
                  </svg>
                )}

                {/* 3. PENICILLIUM SLIDE */}
                {state.slideId === 'penicillium' && (
                  <svg viewBox="0 0 100 100" className="w-4/5 h-4/5 text-blue-800">
                    <circle cx="50" cy="50" r="48" fill="#e0f2fe" opacity="0.15" />

                    {/* Hyphae branching below */}
                    <path d="M 15,85 Q 50,75 85,80" fill="none" stroke="currentColor" strokeWidth="1" />
                    
                    {/* Erect Conidiophore */}
                    <path d="M 42,78 L 46,38" fill="none" stroke="currentColor" strokeWidth="1.2" />

                    {/* Brush-like branching (Metulae and Phialides) */}
                    {/* Branch 1 */}
                    <path d="M 46,38 L 38,26" fill="none" stroke="currentColor" strokeWidth="1.0" />
                    {/* Branch 2 */}
                    <path d="M 46,38 L 54,26" fill="none" stroke="currentColor" strokeWidth="1.0" />
                    
                    {/* Phialides on Branch 1 */}
                    <line x1="38" y1="26" x2="32" y2="18" stroke="currentColor" strokeWidth="0.8" />
                    <line x1="38" y1="26" x2="38" y2="16" stroke="currentColor" strokeWidth="0.8" />
                    <line x1="38" y1="26" x2="43" y2="17" stroke="currentColor" strokeWidth="0.8" />

                    {/* Phialides on Branch 2 */}
                    <line x1="54" y1="26" x2="50" y2="17" stroke="currentColor" strokeWidth="0.8" />
                    <line x1="54" y1="26" x2="55" y2="15" stroke="currentColor" strokeWidth="0.8" />
                    <line x1="54" y1="26" x2="61" y2="18" stroke="currentColor" strokeWidth="0.8" />

                    {/* Chains of spherical conidia (brush effect) */}
                    {/* Chain 1 */}
                    <circle cx="31" cy="14" r="0.9" fill="#2563eb" />
                    <circle cx="30" cy="11" r="0.9" fill="#3b82f6" />
                    <circle cx="29" cy="8" r="0.9" fill="#60a5fa" />
                    {/* Chain 2 */}
                    <circle cx="38" cy="12" r="0.9" fill="#2563eb" />
                    <circle cx="38" cy="9" r="0.9" fill="#3b82f6" />
                    <circle cx="38" cy="6" r="0.9" fill="#60a5fa" />
                    {/* Chain 3 */}
                    <circle cx="44" cy="13" r="0.9" fill="#2563eb" />
                    <circle cx="45" cy="10" r="0.9" fill="#3b82f6" />
                    {/* Chain 4 */}
                    <circle cx="49" cy="13" r="0.9" fill="#2563eb" />
                    <circle cx="48" cy="10" r="0.9" fill="#3b82f6" />
                    {/* Chain 5 */}
                    <circle cx="55" cy="11" r="0.9" fill="#2563eb" />
                    <circle cx="55" cy="8" r="0.9" fill="#3b82f6" />
                    <circle cx="55" cy="5" r="0.9" fill="#60a5fa" />
                    {/* Chain 6 */}
                    <circle cx="62" cy="14" r="0.9" fill="#2563eb" />
                    <circle cx="64" cy="11" r="0.9" fill="#3b82f6" />

                    {isFocused && (
                      <g className="animate-fade-in text-[5px] font-sans font-semibold text-blue-950 fill-blue-950">
                        {/* Conidióforo brush structure */}
                        <line x1="45" y1="50" x2="65" y2="50" stroke="#2563eb" strokeWidth="0.3" />
                        <text x="67" y="51.5" onClick={() => handleDiscoverStructure('Conidióforo')} className="cursor-pointer hover:fill-blue-600">Conidióforo Principal</text>

                        {/* Metulae */}
                        <line x1="41" y1="32" x2="22" y2="32" stroke="#2563eb" strokeWidth="0.3" />
                        <text x="5" y="33" onClick={() => handleDiscoverStructure('Métricas / Ramificações')} className="cursor-pointer hover:fill-blue-600">Métricas (Ramos)</text>

                        {/* Brush chain conidios */}
                        <line x1="45" y1="8" x2="65" y2="8" stroke="#2563eb" strokeWidth="0.3" />
                        <text x="67" y="9" onClick={() => handleDiscoverStructure('Conídios em Cadeia')} className="cursor-pointer hover:fill-blue-600">Conídios (Pincel)</text>
                      </g>
                    )}
                  </svg>
                )}

                {/* 4. SACCHAROMYCES (YEAST) SLIDE */}
                {state.slideId === 'yeast' && (
                  <svg viewBox="0 0 100 100" className="w-4/5 h-4/5 text-amber-600/80">
                    <circle cx="50" cy="50" r="48" fill="#e0f2fe" opacity="0.15" />
                    
                    {/* Unicellular yeast ovals scattered across field */}
                    <g fill="currentColor" opacity="0.85">
                      {/* Standard cell */}
                      <ellipse cx="30" cy="40" rx="6" ry="5.2" stroke="#b45309" strokeWidth="0.5" />
                      <ellipse cx="65" cy="55" rx="7.5" ry="6.2" stroke="#b45309" strokeWidth="0.5" />
                      
                      {/* Cell with active budding (Brotamento) */}
                      <g>
                        {/* Mother cell */}
                        <ellipse cx="48" cy="42" rx="7.8" ry="6.8" stroke="#b45309" strokeWidth="0.5" />
                        {/* Daughter cell budding off */}
                        <circle cx="58" cy="36" r="4.2" stroke="#b45309" strokeWidth="0.5" />
                        {/* Connection pinching */}
                        <path d="M 52,38 L 54,40" stroke="#b45309" strokeWidth="0.5" />
                      </g>

                      {/* Another budding couple */}
                      <g>
                        <ellipse cx="25" cy="70" rx="5" ry="4.2" stroke="#b45309" strokeWidth="0.5" />
                        <circle cx="21" cy="65" r="2.8" stroke="#b45309" strokeWidth="0.5" />
                      </g>

                      {/* Budding triple chain */}
                      <g>
                        <ellipse cx="70" cy="25" rx="6.5" ry="5.5" stroke="#b45309" strokeWidth="0.5" />
                        <ellipse cx="78" cy="20" rx="4.5" ry="3.8" stroke="#b45309" strokeWidth="0.5" />
                        <circle cx="83" cy="16" r="2.5" stroke="#b45309" strokeWidth="0.5" />
                      </g>

                      {/* Tiny cellular details inside mother cell */}
                      <circle cx="46" cy="42" r="1.5" fill="#fef3c7" opacity="0.6" /> {/* Vacuole */}
                      <circle cx="48" cy="45" r="0.6" fill="#78350f" /> {/* Nucleus */}

                      <circle cx="67" cy="54" r="1.8" fill="#fef3c7" opacity="0.6" />
                      <circle cx="63" cy="56" r="0.6" fill="#78350f" />
                    </g>

                    {isFocused && (
                      <g className="animate-fade-in text-[5px] font-sans font-semibold text-amber-950 fill-amber-950">
                        {/* Mother Cell */}
                        <line x1="42" y1="44" x2="25" y2="48" stroke="#b45309" strokeWidth="0.3" />
                        <text x="5" y="52" onClick={() => handleDiscoverStructure('Célula Leveduriforme')} className="cursor-pointer hover:fill-amber-600">Célula Mãe</text>

                        {/* Budding */}
                        <line x1="58" y1="33" x2="65" y2="18" stroke="#b45309" strokeWidth="0.3" />
                        <text x="67" y="17" onClick={() => handleDiscoverStructure('Brotamento / Gemulação')} className="cursor-pointer hover:fill-amber-600">Gemulação / Brotamento</text>

                        {/* Vacuole */}
                        <line x1="67" y1="54" x2="80" y2="64" stroke="#b45309" strokeWidth="0.3" />
                        <text x="81" y="66" className="cursor-default">Vacúolo de Reserva</text>
                      </g>
                    )}
                  </svg>
                )}

              </div>
              
              {/* Ocular circular frame reflection */}
              <div className="absolute inset-0 pointer-events-none bg-[radial-gradient(circle_at_25%_25%,rgba(255,255,255,0.12)_0%,transparent_50%)] z-25" />
            </div>

            {/* Structure discovery status banner */}
            <div className="w-full max-w-md mt-6 space-y-3 z-10">
              <div className="flex justify-between items-center text-xs font-semibold">
                <span className="text-stone-500">Estruturas Citológicas Descobertas:</span>
                <span className="text-emerald-700 font-mono">
                  {discoveredStructures.length} / {activeSlide.structures.length}
                </span>
              </div>
              
              {/* Progress boxes of structures */}
              <div className="grid grid-cols-2 gap-2 text-[10.5px]">
                {activeSlide.structures.map((s) => {
                  const discovered = discoveredStructures.includes(s) || isFocused; 
                  // If perfectly focused, they are revealed
                  if (discovered && !discoveredStructures.includes(s)) {
                    // Lazy-add to discovered list
                    setTimeout(() => handleDiscoverStructure(s), 50);
                  }
                  
                  return (
                    <div 
                      key={s} 
                      className={`py-1.5 px-2.5 rounded-lg border font-medium flex items-center justify-between transition-all ${
                        discovered 
                          ? 'bg-emerald-50 border-emerald-200 text-emerald-800 shadow-xs' 
                          : 'bg-white border-stone-200 text-stone-400'
                      }`}
                    >
                      <span>{s}</span>
                      <span className="text-[9px] font-bold uppercase">
                        {discovered ? '✓ Ok' : '? Focar'}
                      </span>
                    </div>
                  );
                })}
              </div>

              {!isFocused && (
                <div className="text-center text-[10.5px] text-amber-800 bg-amber-50 border border-amber-200/80 p-2 rounded-lg animate-pulse shadow-xs">
                  ⚠ A imagem está turva. Use o "Botão de Foco" para estabilizar as hifas e esporos!
                </div>
              )}
            </div>

          </div>

          {/* Slide Scientific Details */}
          <div className="bg-white border border-stone-200 p-5 rounded-xl shadow-xs">
            <h3 className="text-sm font-semibold text-stone-800 mb-2">
              Ficha Técnica do Espécime: <span className="text-emerald-800">{activeSlide.name}</span>
            </h3>
            <p className="text-xs text-stone-600 leading-relaxed">
              {activeSlide.description}
            </p>
          </div>

        </div>

      </div>
    </div>
  );
}
